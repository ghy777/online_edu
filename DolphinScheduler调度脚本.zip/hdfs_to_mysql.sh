#! /bin/bash

DATAX_HOME=/opt/module/datax

#DataX导出路径不允许存在空文件，该函数作用为清理空文件
handle_export_path(){
  for i in `hadoop fs -ls -R $1 | awk '{print $8}'`; do
    hadoop fs -test -z $i
    if [[ $? -eq 0 ]]; then
      echo "$i文件大小为0，正在删除"
      hadoop fs -rm -r -f $i
    fi
  done
}

#数据导出
export_data() {
  datax_config=$1
  export_dir=$2
  handle_export_path $export_dir
  $DATAX_HOME/bin/datax.py -p"-Dexportdir=$export_dir" $datax_config
}

case $1 in
  "ads_course_order_count")
    export_data /opt/module/datax/job/export/edu_report.ads_course_order_count.json /warehouse/online_edu/ads/ads_course_order_count
  ;;
  "ads_new_order_user_stats")
    export_data /opt/module/datax/job/export/edu_report.ads_new_order_user_stats.json /warehouse/online_edu/ads/ads_new_order_user_stats
  ;;  
  "ads_trade_order_by_source")
    export_data /opt/module/datax/job/export/edu_report.ads_trade_order_by_source.json /warehouse/online_edu/ads/ads_trade_order_by_source
  ;;
  "ads_category_visitor_retention")
    export_data /opt/module/datax/job/export/edu_report.ads_category_visitor_retention.json /warehouse/online_edu/ads/ads_category_visitor_retention
  ;;
  "ads_subject_visitor_retention")
    export_data /opt/module/datax/job/export/edu_report.ads_subject_visitor_retention.json /warehouse/online_edu/ads/ads_subject_visitor_retention
  ;;
  "ads_course_visitor_retention")
    export_data /opt/module/datax/job/export/edu_report.ads_course_visitor_retention.json /warehouse/online_edu/ads/ads_course_visitor_retention
  ;;  
  "ads_course_review_count")
    export_data /opt/module/datax/job/export/edu_report.ads_course_review_count.json /warehouse/online_edu/ads/ads_course_review_count
  ;;
  "ads_new_order_user_stats")
    export_data /opt/module/datax/job/export/edu_report.ads_new_order_user_stats.json /warehouse/online_edu/ads/ads_new_order_user_stats
  ;;
  "ads_order_user_age")
    export_data /opt/module/datax/job/export/edu_report.ads_order_user_age.json /warehouse/online_edu/ads/ads_order_user_age
  ;;
  "ads_category_order_count")
    export_data /opt/module/datax/job/export/edu_report.ads_category_order_count.json /warehouse/online_edu/ads/ads_category_order_count
  ;;  
  "ads_subject_order_count")
    export_data /opt/module/datax/job/export/edu_report.ads_subject_order_count.json /warehouse/online_edu/ads/ads_subject_order_count
  ;;
  "ads_course_order_count")
    export_data /opt/module/datax/job/export/edu_report.ads_course_order_count.json /warehouse/online_edu/ads/ads_course_order_count
  ;;
  "ads_course_review_count")
    export_data /opt/module/datax/job/export/edu_report.ads_course_review_count.json /warehouse/online_edu/ads/ads_course_review_count
  ;;
  "ads_category_visitor_retention")
    export_data /opt/module/datax/job/export/edu_report.ads_category_visitor_retention.json /warehouse/online_edu/ads/ads_category_visitor_retention
  ;;  
  "ads_subject_visitor_retention")
    export_data /opt/module/datax/job/export/edu_report.ads_subject_visitor_retention.json /warehouse/online_edu/ads/ads_subject_visitor_retention
  ;;
  "ads_course_visitor_retention")
    export_data /opt/module/datax/job/export/edu_report.ads_course_visitor_retention.json /warehouse/online_edu/ads/ads_course_visitor_retention
  ;;
  "ads_trade_synthesis")
    export_data /opt/module/datax/job/export/edu_report.ads_trade_synthesis.json /warehouse/online_edu/ads/ads_trade_synthesis
  ;;
  "ads_order_by_province")
    export_data /opt/module/datax/job/export/edu_report.ads_order_by_province.json /warehouse/online_edu/ads/ads_order_by_province
  ;;
  "ads_paper_synthesis")
    export_data /opt/module/datax/job/export/edu_report.ads_paper_synthesis.json /warehouse/online_edu/ads/ads_paper_synthesis
  ;;
  "ads_course_test")
    export_data /opt/module/datax/job/export/edu_report.ads_course_test.json /warehouse/online_edu/ads/ads_course_test
  ;;
  "ads_paper_score")
    export_data /opt/module/datax/job/export/edu_report.ads_paper_score.json /warehouse/online_edu/ads/ads_paper_score
  ;;
  "ads_question_currect_rate")
    export_data /opt/module/datax/job/export/edu_report.ads_question_currect_rate.json /warehouse/online_edu/ads/ads_question_currect_rate
  ;;
  "ads_chapter_play")
    export_data /opt/module/datax/job/export/edu_report.ads_chapter_play.json /warehouse/online_edu/ads/ads_chapter_play
  ;;
  "ads_course_play")
    export_data /opt/module/datax/job/export/edu_report.ads_course_play.json /warehouse/online_edu/ads/ads_course_play
  ;;
  "ads_course_finish")
    export_data /opt/module/datax/job/export/edu_report.ads_course_finish.json /warehouse/online_edu/ads/ads_course_finish
  ;;
  "ads_course_finish_synthesis")
    export_data /opt/module/datax/job/export/edu_report.ads_course_finish_synthesis.json /warehouse/online_edu/ads/ads_course_finish_synthesis
  ;;
  "ads_course_finish_avg_user")
    export_data /opt/module/datax/job/export/edu_report.ads_course_finish_avg_user.json /warehouse/online_edu/ads/ads_course_finish_avg_user
  ;;
  "all")
	export_data /opt/module/datax/job/export/edu_report.ads_course_order_count.json /warehouse/online_edu/ads/ads_course_order_count
    export_data /opt/module/datax/job/export/edu_report.ads_page_path.json /warehouse/online_edu/ads/ads_page_path
    export_data /opt/module/datax/job/export/edu_report.ads_trade_order_by_source.json /warehouse/online_edu/ads/ads_trade_order_by_source
    export_data /opt/module/datax/job/export/edu_report.ads_category_visitor_retention.json /warehouse/online_edu/ads/ads_category_visitor_retention
    export_data /opt/module/datax/job/export/edu_report.ads_subject_visitor_retention.json /warehouse/online_edu/ads/ads_subject_visitor_retention
    export_data /opt/module/datax/job/export/edu_report.ads_course_visitor_retention.json /warehouse/online_edu/ads/ads_course_visitor_retention
    export_data /opt/module/datax/job/export/edu_report.ads_course_review_count.json /warehouse/online_edu/ads/ads_course_review_count
    export_data /opt/module/datax/job/export/edu_report.ads_new_order_user_stats.json /warehouse/online_edu/ads/ads_new_order_user_stats
    export_data /opt/module/datax/job/export/edu_report.ads_order_user_age.json /warehouse/online_edu/ads/ads_order_user_age
    export_data /opt/module/datax/job/export/edu_report.ads_category_order_count.json /warehouse/online_edu/ads/ads_category_order_count
    export_data /opt/module/datax/job/export/edu_report.ads_subject_order_count.json /warehouse/online_edu/ads/ads_subject_order_count
    export_data /opt/module/datax/job/export/edu_report.ads_course_order_count.json /warehouse/online_edu/ads/ads_course_order_count
    export_data /opt/module/datax/job/export/edu_report.ads_traffic_stats_by_source.json /warehouse/online_edu/ads/ads_traffic_stats_by_source
    export_data /opt/module/datax/job/export/edu_report.ads_user_retention.json /warehouse/online_edu/ads/ads_user_retention
    export_data /opt/module/datax/job/export/edu_report.ads_user_change.json /warehouse/online_edu/ads/ads_user_change
    export_data /opt/module/datax/job/export/edu_report.ads_user_action.json.json /warehouse/online_edu/ads/ads_user_action
    export_data /opt/module/datax/job/export/edu_report.ads_trade_synthesis.json /warehouse/online_edu/ads/ads_trade_synthesis
    export_data /opt/module/datax/job/export/edu_report.ads_order_by_province.json /warehouse/online_edu/ads/ads_order_by_province
    export_data /opt/module/datax/job/export/edu_report.ads_paper_synthesis.json /warehouse/online_edu/ads/ads_paper_synthesis
    export_data /opt/module/datax/job/export/edu_report.ads_course_test.json /warehouse/online_edu/ads/ads_course_test
    export_data /opt/module/datax/job/export/edu_report.ads_paper_score.json /warehouse/online_edu/ads/ads_paper_score
    export_data /opt/module/datax/job/export/edu_report.ads_question_correct_rate.json /warehouse/online_edu/ads/ads_question_correct_rate
    export_data /opt/module/datax/job/export/edu_report.ads_chapter_play.json /warehouse/online_edu/ads/ads_chapter_play
    export_data /opt/module/datax/job/export/edu_report.ads_course_play.json /warehouse/online_edu/ads/ads_course_play
    export_data /opt/module/datax/job/export/edu_report.ads_course_finish.json /warehouse/online_edu/ads/ads_course_finish
    export_data /opt/module/datax/job/export/edu_report.ads_course_finish_synthesis.json /warehouse/online_edu/ads/ads_course_finish_synthesis
    export_data /opt/module/datax/job/export/edu_report.ads_course_finish_avg_user.json /warehouse/online_edu/ads/ads_course_finish_avg_user
  ;;
esac

