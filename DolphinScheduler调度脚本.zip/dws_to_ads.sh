#!/bin/bash

APP=edu
# 如果是输入的日期按照取输入日期；如果没输入日期取当前时间的前一天
if [ -n "$2" ] ;then
    do_date=$2
else 
    do_date=date -d "-1 day" +%F
fi

ads_traffic_stats_by_source="
insert overwrite table ${APP}.ads_traffic_stats_by_source
select * from ${APP}.ads_traffic_stats_by_source
union
select
    '$do_date' dt,
    recent_days,
    source,
    cast(count(distinct(mid_id)) as bigint) uv_count,
    cast(avg(during_time_1d)/1000 as bigint) avg_duration_sec,
    cast(avg(page_count_1d) as bigint) avg_page_count,
    cast(count(*) as bigint) sv_count,
    cast(sum(if(page_count_1d=1,1,0))/count(*) as decimal(16,2)) bounce_rate
from ${APP}.dws_traffic_session_page_view_1d lateral view explode(array(1,7,30)) tmp as recent_days
where dt>=date_add('$do_date',-recent_days+1) and source is not null
group by recent_days,source;
"
ads_page_path="
insert overwrite table ${APP}.ads_page_path
select * from ${APP}.ads_page_path
union
select
    '$do_date' dt,
    source,
    nvl(target,'null'),
    count(*) path_count
from
(
    select
        concat('step-',rn,':',page_id) source,
        concat('step-',rn+1,':',next_page_id) target
    from
    (
        select
            page_id,
            lead(page_id,1,null) over(partition by session_id order by view_time) next_page_id,
            row_number() over (partition by session_id order by view_time) rn
        from ${APP}.dwd_traffic_page_view_inc
        where dt='$do_date'
    )t1
)t2
group by source,target;
"
ads_trade_order_by_source="
insert overwrite table ${APP}.ads_trade_order_by_source
select * from ${APP}.ads_trade_order_by_source
union
select
    '$do_date' dt,
    cast(recent_days2 as bigint) as recent_days,
    source,
    cast(count(distinct (session_id)) as bigint) ,
    cast(count(distinct (user_id)) as bigint),
    cast(sum(order_total_amount_1d) as bigint) od_amount,
    cast(cast(count(distinct(user_id)) as bigint)/cast(count(distinct (session_id) )as bigint) as DECIMAL(16, 2))  as renten_rate
from(
    select
    recent_days2,
    source,
    session_id
    from ${APP}.dws_traffic_session_page_view_1d lateral view explode(array(1,7,30)) tmp as recent_days2
    where dt>=date_add('$do_date',-recent_days2+1) and source is not null
    group by recent_days2,source,session_id
        ) e1
left join (
    select
        source_site,
        recent_days1,
        user_id,
        order_total_amount_1d
    from ${APP}.dws_trade_user_source_order_1d lateral view explode(array(1,7,30)) tmp as recent_days1
    where dt>=date_add('$do_date',-recent_days1+1) and source_site is not null
    group by source_site,recent_days1,user_id,order_total_amount_1d
    )c1 on recent_days1=recent_days2 and source_site=source
group by recent_days2,source;
"
ads_user_change="
insert overwrite table ${APP}.ads_user_change
select * from ${APP}.ads_user_change
union
select
    churn.dt,
    user_churn_count,
    user_back_count
from
(
    select
        '$do_date' dt,
        count(*) user_churn_count
    from ${APP}.dws_user_user_login_td
    where dt='$do_date'
    and login_date_last<=date_sub('$do_date',7)
)churn
join
(
    select
        '$do_date' dt,
        count(*) user_back_count
    from
    (
        select
            user_id,
            login_date_last
        from ${APP}.dws_user_user_login_td
        where dt='$do_date'
    )t1
    join
    (
        select
            user_id,
            login_date_last login_date_previous
        from ${APP}.dws_user_user_login_td
        where dt=date_sub('$do_date',1)
    )t2
    on t1.user_id=t2.user_id
    where datediff(login_date_last,login_date_previous)>=8
)back
on churn.dt=back.dt;
"
ads_user_retention="
insert overwrite table ${APP}.ads_user_retention
select * from ${APP}.ads_user_retention
union
select
    '$do_date' dt,
    login_date_first create_date,
    datediff('$do_date',login_date_first) retention_day,
    sum(if(login_date_last='$do_date',1,0)) retention_count,
    count(*) new_user_count,
    cast(sum(if(login_date_last='$do_date',1,0))/count(*)*100 as decimal(16,2)) retention_rate
from
(
    select
        user_id,
        date_id login_date_first
    from ${APP}.dwd_user_register_inc
    where dt>=date_add('$do_date',-7)
    and dt<='$do_date'
)t1
join
(
    select
        user_id,
        login_date_last
    from ${APP}.dws_user_user_login_td
    where dt='$do_date'
)t2
on t1.user_id=t2.user_id
group by login_date_first;
"
ads_user_stats="
insert overwrite table ${APP}.ads_user_stats
select * from ${APP}.ads_user_stats
union
select
       distinct
    '$do_date' dt,
    t1.recent_days,
    new_user_count,
    active_user_count
from
(
    select
        recent_days,
        sum(if(login_date_last>=date_add('$do_date',-recent_days+1),1,0)) active_user_count
    from  ${APP}.dws_user_user_login_td lateral view explode(array(1,7,30)) tmp as recent_days
    where dt='$do_date'
    group by recent_days
)t1
join
(
    select
        recent_days,
        sum(if(date_format(create_time,'yyyy-MM-dd')>=date_add('$do_date',-recent_days+1),1,0)) new_user_count
    from  ${APP}.dim_user_zip lateral view explode(array(1,7,30)) tmp as recent_days
    where dt = '9999-12-31'
    group by recent_days  
)t2
on t1.recent_days=t2.recent_days;
"
ads_user_action="
insert overwrite table ${APP}.ads_user_action
select * from ${APP}.ads_user_action
union
select
    1 recent_days,
    '$do_date' dt,
    home_count,
    course_detail_count,
    cart_count,
    order_count,
    payment_count
from
(
    select
        1 recent_days,
        sum(if(page_id='home',1,0)) home_count,
        sum(if(page_id='course_detail',1,0)) course_detail_count
    from ${APP}.dws_traffic_page_visitor_page_view_1d
    where dt='$do_date'
    and page_id in ('home','course_detail')
)page
join
(
    select
        1 recent_days,
        count(*) cart_count
    from ${APP}.dws_trade_user_cart_add_1d
    where dt='$do_date'
)cart
on page.recent_days=cart.recent_days
join
(
    select
        1 recent_days,
        count(*) order_count
    from ${APP}.dws_trade_user_source_order_1d
    where dt='$do_date'
)ord
on page.recent_days=ord.recent_days
join
(
    select
        1 recent_days,
        count(*) payment_count
    from ${APP}.dws_trade_user_payment_1d
    where dt='$do_date'
)pay
on page.recent_days=pay.recent_days
union
select
    7 recent_days,
    '$do_date' dt,
    home_count,
    course_detail_count,
    cart_count,
    order_count,
    payment_count
from
(
    select
        7 recent_days,
        sum(if(page_id='home',1,0)) home_count,
        sum(if(page_id='course_detail',1,0)) course_detail_count
    from ${APP}.dws_traffic_page_visitor_page_view_1d
    where dt >= date_sub('$do_date',7) and dt <='$do_date'
    and page_id in ('home','course_detail')
)page
join
(
    select
        7 recent_days,
        count(*) cart_count
    from ${APP}.dws_trade_user_cart_add_1d
     where dt >= date_sub('$do_date',7) and dt <='$do_date'
)cart
on page.recent_days=cart.recent_days
join
(
    select
        7 recent_days,
        count(*) order_count
    from ${APP}.dws_trade_user_source_order_1d
    where dt >= date_sub('$do_date',7) and dt <='$do_date'
)ord
on page.recent_days=ord.recent_days
join
(
    select
        7 recent_days,
        count(*) payment_count
    from ${APP}.dws_trade_user_payment_1d
    where dt >= date_sub('$do_date',7) and dt <='$do_date'
)pay
on page.recent_days=pay.recent_days
union
select
    30 recent_days,
    '$do_date' dt,
    home_count,
    course_detail_count,
    cart_count,
    order_count,
    payment_count
from
(
    select
        30 recent_days,
        sum(if(page_id='home',1,0)) home_count,
        sum(if(page_id='course_detail',1,0)) course_detail_count
    from ${APP}.dws_traffic_page_visitor_page_view_1d
    where dt >= date_sub('$do_date',29) and dt <='$do_date'
    and page_id in ('home','course_detail')
)page
join
(
    select
        30 recent_days,
        count(*) cart_count
    from ${APP}.dws_trade_user_cart_add_1d
     where dt >= date_sub('$do_date',29) and dt <='$do_date'
)cart
on page.recent_days=cart.recent_days
join
(
    select
        30 recent_days,
        count(*) order_count
    from ${APP}.dws_trade_user_source_order_1d
    where dt >= date_sub('$do_date',29) and dt <='$do_date'
)ord
on page.recent_days=ord.recent_days
join
(
    select
        30 recent_days,
        count(*) payment_count
    from ${APP}.dws_trade_user_payment_1d
    where dt >= date_sub('$do_date',29) and dt <='$do_date'
)pay
on page.recent_days=pay.recent_days;
"
ads_new_order_user_stats="
insert overwrite table ${APP}.ads_new_order_user_stats
select * from ${APP}.ads_new_order_user_stats
union
select
    '$do_date' dt,
    recent_days,
    count(distinct (if(order_date_first>=date_add('$do_date',-recent_days+1),user_id,null))) new_order_user_count
from ${APP}.dws_trade_user_order_td lateral view explode(array(1,7,30)) tmp as recent_days
where dt='$do_date'
group by recent_days;
"
ads_order_user_age="
insert overwrite table ${APP}.ads_order_user_age
select * from ${APP}.ads_order_user_age
union
select
'$do_date' dt,
       recent_days,
sum(if(age<18 and age>0,1,0)) order_user_count_minor,
sum(if(age>=18 and age<=35,1,0)) order_user_count_youth,
sum(if(age<60 and age>35,1,0)) order_user_count_midlife,
sum(if(age>=60,1,0)) order_user_count_aged
from
(select distinct
    user_id,
    recent_days,
    if(month>=0,year,year-1) as age
from ${APP}.dws_trade_user_source_order_1d
join
     (select id,
            year(current_date())-year(birthday) year,
            month(current_date())-month(birthday) month,
            recent_days
      from ${APP}.dim_user_zip lateral view explode(array(1,7,30)) tmp as recent_days
      where dt >= date_sub('$do_date',recent_days-1)
     )t1 on user_id = id)t2
group by recent_days;
"
ads_course_order_count="
insert overwrite table ${APP}.ads_course_order_count
select * from ${APP}.ads_course_order_count
union
select
  '$do_date'dt
 ,recent_days
 ,course_name
 , sum(order_count_1d)  order_count
 ,sum( order_u_count_1d)order_user_count
 ,sum(order_total_amount_1d)order_amount_count
from
    ${APP}.dws_trade_course_order_1d lateral view explode(array(1,7,30))tmp as recent_days
where dt>=date_sub('$do_date',recent_days-1)
group by recent_days,course_name;
"
ads_subject_order_count="
insert overwrite table ${APP}.ads_subject_order_count
select * from ${APP}.ads_subject_order_count
union
select
     '$do_date' dt,
    recent_days,
     subject_name
, sum(order_count_1d)  order_count
,sum( order_u_count_1d)order_user_count
,sum(order_total_amount_1d)order_amount_count
from (
    select
 recent_days
 ,course_id
 , order_count_1d
 , order_u_count_1d
 ,order_total_amount_1d
from ${APP}.dws_trade_course_order_1d lateral view explode(array(1,7,30))tmp as recent_days
where dt>=date_sub('$do_date',recent_days-1)
) c1 left join ${APP}.dim_course_full on id = course_id
group by subject_name,recent_days;
"
ads_category_order_count="
insert overwrite table ${APP}.ads_category_order_count
select * from ${APP}.ads_category_order_count
union
select
        '$do_date'dt,
       recent_days,
       category_name
    , sum(order_count_1d)  order_count
    ,sum( order_u_count_1d)order_user_count
    ,sum(order_total_amount_1d)order_amount_count
from (
    select
 recent_days
 ,course_id
 , order_count_1d
 , order_u_count_1d
 ,order_total_amount_1d
from ${APP}.dws_trade_course_order_1d lateral view explode(array(1,7,30))tmp as recent_days
where dt>=date_sub('$do_date',recent_days-1) and dt <= '$do_date'
) c1 left join ${APP}.dim_course_full on id = course_id
group by category_name,recent_days;
"
ads_course_review_count="
insert overwrite table ${APP}.ads_course_review_count
select * from ${APP}.ads_course_review_count
union
select
    ' $do_date'dt,
    recent_days,
     course_name,
     avg(review_stars)user_review_avg,
     count(distinct user_id)review_user_count,
     count(if(review_stars=5,1,null))/count(user_id) hige_review_rate
        from ( select
                *
from ${APP}.dwd_interaction_course_review_inc lateral view explode(array(1,7,30))tmp as recent_days ) c1
left join ${APP}.dim_course_full on course_id=dim_course_full.id
where c1.dt>=date_sub('$do_date',recent_days-1)
group by recent_days,course_name;
"
ads_course_visitor_retention="
insert overwrite ${APP}.table ads_course_visitor_retention
select * from ${APP}.ads_course_visitor_retention
union
select dt,
       retention_day,
       course_name,
       new_user_count,
       retention_rate
from (
     select '$do_date' dt,
       datediff('$do_date',date_id)+1   retention_day,
       t1.course_id,
       count(distinct user1)  new_user_count,
       count(user2)/count(user1) retention_rate
from (
     select  course_id,
              user_id user1,  
                date_id
    from ${APP}.dwd_study_user_video_inc
    where dt>=date_add('$do_date',-6)
         and dt<='$do_date'
         and is_new = '1'
         ) t1
left join(
    select
        course_id,
        user_id user2
    from ${APP}.dws_trade_user_course_order_1d
    where dt>=date_add('$do_date',-6)
    and dt<='$do_date'
) t2 on t1.course_id = t2.course_id and t1.user1 = t2.user2
group by t1.course_id,date_id
         ) t3
left join (
    select
            distinct
            id,
            course_name
    from ${APP}.dim_course_full
    where dt>=date_sub('$do_date',6)
    )dcf on dcf.id = t3.course_id;
"
ads_subject_visitor_retention="
insert overwrite table ${APP}.ads_subject_visitor_retention
select * from ${APP}.ads_subject_visitor_retention
union
select
       '$do_date'dt,
       retention_day,
       subject_name,
       sum(new_user_count),
       count(user2)/sum(new_user_count) retention_rate
from (
     select '$do_date' dt,
            datediff('$do_date',date_id)+1   retention_day,
            t1.course_id,
            count(distinct user1)  new_user_count,
            user2
from (
     select   course_id,
              user_id user1,
                date_id
    from ${APP}.dwd_study_user_video_inc
    where dt>=date_add('$do_date',-6)
        and dt<='$do_date'
        and is_new = '1'
    ) t1
left join(
    select
        course_id,
        user_id user2
    from ${APP}.dws_trade_user_course_order_1d
    where dt>=date_add('$do_date',-6)
    and dt<='$do_date'
) t2 on t1.course_id = t2.course_id and t1.user1 = t2.user2
group by t1.course_id,date_id,user2
         ) t3
left join (
    select
        distinct
                id,
            subject_name
    from ${APP}.dim_course_full
    where dt>=date_sub('$do_date',6)
    )dcf on dcf.id = t3.course_id
group by subject_name, retention_day;
"
ads_category_visitor_retention="
insert overwrite table ${APP}.ads_category_visitor_retention
select * from ${APP}.ads_category_visitor_retention
union
select'$do_date' dt,
       retention_day,
       category_name,
       sum(new_user_count),
       count(user2)/sum(new_user_count) retention_rate
from (
     select '$do_date' dt,
       datediff('$do_date',date_id)+1   retention_day,
       t1.course_id,
       count(distinct user1)  new_user_count,
       user2 
from (
     select  course_id,
              user_id user1,  
                date_id
from ${APP}.dwd_study_user_video_inc
where dt>=date_add('$do_date',-6)
    and dt<='$do_date'
 and is_new = '1'
         ) t1
left join(
    select
        course_id,
        user_id user2
    from ${APP}.dws_trade_user_course_order_1d
    where dt>=date_add('$do_date',-6)
    and dt<='$do_date'
) t2 on t1.course_id = t2.course_id and t1.user1 = t2.user2
group by t1.course_id,date_id,user2
         ) t3
left join (
    select
        distinct
                id,
                category_name
    from ${APP}.dim_course_full
    where dt>=date_sub('$do_date',6)
    )dcf on dcf.id = t3.course_id
group by category_name, retention_day;
"
ads_trade_synthesis="
insert overwrite table ${APP}.ads_trade_synthesis
select * from ${APP}.ads_trade_synthesis
union
select
     '$do_date'dt
     ,recent_days
     ,sum(order_total_amount_1d) order_amunt
     ,sum(order_count_1d)order_num
     ,count(distinct user_id)order_user_num
from ${APP}.dws_trade_user_course_order_1d lateral view explode(array(1,7,30))tmp as recent_days
where dt>=date_sub('$do_date',recent_days-1) and dt <='$do_date'
group by recent_days;
"
ads_order_by_province="
insert overwrite table ${APP}.ads_order_by_province
select * from ${APP}.ads_order_by_province
union
select
    '$do_date' dt,
    1 recent_days,
    province_id,
    province_name,
    area_code,
    iso_code,
    iso_3166_2,
    order_count_1d,
    order_total_amount_1d
from ${APP}.dws_trade_province_order_1d
where dt='$do_date'
union
select
    '$do_date' dt,
    recent_days,
    province_id,
    province_name,
    area_code,
    iso_code,
    iso_3166_2,
    case recent_days
        when 7 then order_count_7d
        when 30 then order_count_30d
    end order_count,
    case recent_days
        when 7 then order_total_amount_7d
        when 30 then order_total_amount_30d
    end order_total_amount
from ${APP}.dws_trade_province_order_nd lateral view explode(array(7,30)) tmp as recent_days
where dt='$do_date';
"
ads_paper_synthesis="
insert overwrite table ${APP}.ads_paper_synthesis
select * from ${APP}.ads_paper_synthesis
union
select  '$do_date' dt,
		1   		recent_days,
		paper_title,
		avg(score) 			paper_score_avg,
		avg(duration_sec)   paper_duration_avg,
		count(distinct user_id) paper_user_count
from ${APP}.dws_study_user_exam_score_1d
where dt='$do_date'
group by paper_title
union
select  '$do_date' dt,
		7   		    recent_days,
		paper_title ,
		avg(score) 			paper_score_avg,
		avg(duration_sec)   paper_duration_avg,
		count(distinct user_id) paper_user_count
from ${APP}.dws_study_user_exam_score_1d
where dt >= date_sub('$do_date',6)
group by paper_title
union
select  '$do_date' dt,
		30   		    recent_days,
		paper_title ,
		avg(score) 			paper_score_avg,
		avg(duration_sec)   paper_duration_avg,
		count(distinct user_id) paper_user_count
from ${APP}.dws_study_user_exam_score_1d
where dt >= date_sub('$do_date',29)
group by paper_title;
"
ads_course_test="
insert overwrite table ${APP}.ads_course_test
select * from ${APP}.ads_course_test
union
select
       dt,
       recent_days,
       course_name,
       course_score_avg,
       course_duration_avg,
       course_user_count
from (
    select  '$do_date' dt,
		1   				recent_days,
		course_id ,
		avg(score)  		course_score_avg,
		avg(duration_sec)   course_duration_avg,
		count(distinct user_id) course_user_count
from ${APP}.dws_study_user_exam_score_1d
where dt = '$do_date'
group by course_id
union
select  '$do_date'  dt,
		7   				recent_days,
		course_id ,
		avg(score)  		course_score_avg,
		avg(duration_sec)   course_duration_avg,
		count(distinct user_id) course_user_count
from ${APP}.dws_study_user_exam_score_1d
where dt >= date_sub('$do_date',6) and dt<= '$do_date'
group by course_id
union
select  '$do_date' dt,
		30   				recent_days,
		course_id ,
		avg(score)  		course_score_avg,
		avg(duration_sec)   course_duration_avg,
		count(distinct user_id) course_user_count
from ${APP}.dws_study_user_exam_score_1d
where dt >= date_sub('$do_date',29) and dt<= '$do_date'
group by course_id
) t1
left join(
    select distinct id,
            course_name
    from ${APP}.dim_course_full
) dcf on dcf.id = course_id;
"
ads_paper_score="
insert overwrite table ${APP}.ads_paper_score
select * from ${APP}.ads_paper_score
union
select  '$do_date'  dt,
		1           recent_days,
		paper_title,
		count(if(score<60,1,null))         score_under_60,
		count(if(score>=60 and score<70,1,null))  score_under_60_70,
		count(if(score>=70 and score<80,1,null))    score_under_70_80,
		count(if(score>=80 and score<90,1,null))     score_under_80_90,
		count(if(score>=90 and score<100,1,null))    score_under_90_100
from ${APP}.dws_study_user_exam_score_1d
where dt = '$do_date'
group by paper_title
union
select  '$do_date'  dt,
		7           recent_days,
		paper_title,
		count(if(score<60,1,null))         score_under_60,
		count(if(score>=60 and score<70,1,null))  score_under_60_70,
		count(if(score>=70 and score<80,1,null))    score_under_70_80,
		count(if(score>=80 and score<90,1,null))     score_under_80_90,
		count(if(score>=90 and score<100,1,null))    score_under_90_100
from ${APP}.dws_study_user_exam_score_1d
where dt >= date_sub('$do_date',6) and dt<= '$do_date'
group by paper_title
union
select  '$do_date'  dt,
		30           recent_days,
		paper_title,
		count(if(score<60,1,null))         score_under_60,
		count(if(score>=60 and score<70,1,null))  score_under_60_70,
		count(if(score>=70 and score<80,1,null))    score_under_70_80,
		count(if(score>=80 and score<90,1,null))     score_under_80_90,
		count(if(score>=90 and score<100,1,null))    score_under_90_100
from ${APP}.dws_study_user_exam_score_1d
where dt >= date_sub('$do_date',29) and dt<= '$do_date'
group by paper_title;
"
ads_question_currect_rate="
insert overwrite table ${APP}.ads_question_currect_rate
select * from ${APP}.ads_question_currect_rate
union
select 	'$do_date',
		 1 recent_days,
		data.question_id  question_txt,
		sum(data.is_correct)/count(*)  question_currect_rate
from  ${APP}.ods_test_exam_question_inc
where dt = '$do_date'
group by data.question_id
union
select 	'$do_date',
		 7 recent_days,
		data.question_id  question_txt,
		sum(data.is_correct)/count(*)  question_currect_rate
from  ${APP}.ods_test_exam_question_inc
where dt >= date_sub('$do_date',6) and dt<= '$do_date'
group by data.question_id
union
select 	'$do_date',
		 30 recent_days,
		data.question_id  question_txt,
		sum(data.is_correct)/count(*)  question_currect_rate
from  ${APP}.ods_test_exam_question_inc
where dt >= date_sub('$do_date',29) and dt<= '$do_date'
group by data.question_id;
"
ads_chapter_play="
insert overwrite table ${APP}.ads_chapter_play
select * from ${APP}.ads_chapter_play
union
select
       dt,
	 recent_days,
	chapter_name,
	chapter_play_coun,
	chapter_user_paly_avg,
	chapter_user_count
from (
         select '$do_date'                            dt,
                1                                       recent_days,
                chapter_id,
                count(video_id)                         chapter_play_coun,
                sum(play_sec) / count(distinct user_id) chapter_user_paly_avg,
                count(distinct user_id)                 chapter_user_count
         from ${APP}.dwd_study_user_video_inc
         where dt = '$do_date'
         group by chapter_id
         union
         select '$do_date',
                7                                       recent_days,
                chapter_id,
                count(video_id)                         chapter_play_coun,
                sum(play_sec) / count(distinct user_id) chapter_user_paly_avg,
                count(distinct user_id)                 chapter_user_count
         from ${APP}.dwd_study_user_video_inc
         where dt >= date_sub('$do_date', 6)
           and dt <= '$do_date'
         group by chapter_id
         union
         select '$do_date',
                30                                      recent_days,
                chapter_id,
                count(video_id)                         chapter_play_coun,
                sum(play_sec) / count(distinct user_id) chapter_user_paly_avg,
                count(distinct user_id)                 chapter_user_count
         from ${APP}.dwd_study_user_video_inc
         where dt >= date_sub('$do_date', 29)
           and dt <= '$do_date'
         group by chapter_id
     )  t1 left join (
	select id,
			chapter_name
	from ${APP}.dim_chapter_video_full
	where dt='$do_date'
) t2 on t1.chapter_id = t2.id;
"
ads_course_play="
insert overwrite table ${APP}.ads_course_play
select * from ${APP}.ads_course_play
union
select '$do_date' dt ,
		1    recent_days,
		course_name,
		course_play_count,
		course_user_paly_avg,
		course_user_count
from (
    select
        course_id,
        count(video_id) course_play_count,
        sum(play_sec)/count(distinct user_id) course_user_paly_avg,
        count(distinct user_id)  course_user_count
from ${APP}.dwd_study_user_video_inc
where dt = '$do_date'
group by course_id
) t1 left join (
	select  id,
			course_name
	from ${APP}.dim_course_full
	where dt='$do_date'
) t2 on t1.course_id = t2.id
union
select '$do_date',
		7    recent_days,
		course_name,
		course_play_count,
		course_user_paly_avg,
		course_user_count
from (
    select
        course_id,
        count(video_id) course_play_count,
        sum(play_sec)/count(distinct user_id) course_user_paly_avg,
        count(distinct user_id)  course_user_count
from ${APP}.dwd_study_user_video_inc
where dt >= date_sub('$do_date',6)
group by course_id
) t1 left join (
	select  id,
			course_name
	from ${APP}.dim_course_full
	where dt >= date_sub('$do_date',6)
) t2 on t1.course_id = t2.id
union
select '$do_date',
		30    recent_days,
		course_name,
		course_play_count,
		course_user_paly_avg,
		course_user_count
from (
    select
        course_id,
        count(video_id) course_play_count,
        sum(play_sec)/count(distinct user_id) course_user_paly_avg,
        count(distinct user_id)  course_user_count
from ${APP}.dwd_study_user_video_inc
where dt >= date_sub('$do_date',29)
group by course_id
) t1 left join (
	select  id,
			course_name
	from ${APP}.dim_course_full
	where dt >= date_sub('$do_date',29)
) t2 on t1.course_id = t2.id;
"
ads_course_finish="
insert overwrite table ${APP}.ads_course_finish
select * from ${APP}.ads_course_finish
union
select distinct
       dt,
       recent_days,
       course_name,
       course_user_finish_count
from (
     select
       '$do_date' dt,
       1 recent_days,
       course_id,
       count(distinct user_id) course_user_finish_count
from ${APP}.dws_study_video_suc_1d
where dt = '$do_date'
group by course_id
union
select
       '$do_date' dt,
       7 recent_days,
       course_id,
       count(distinct user_id) course_user_finish_count
from ${APP}.dws_study_video_suc_1d
where dt >= date_sub('$do_date',6) and dt<= '$do_date'
group by course_id
union
select
        '$do_date' dt,
       30 recent_days,
       course_id,
       count(distinct user_id) course_user_finish_count
from ${APP}.dws_study_video_suc_1d
where dt >= date_sub('$do_date',29) and dt<= '$do_date'
group by course_id
    ) t1 left join (
    select id,
           course_name
    from   ${APP}.dim_course_full
    where dt >= date_sub('$do_date',29) and dt<= '$do_date'
    ) dcf on dcf.id = t1.course_id;
"
ads_course_finish_synthesis="
insert overwrite table ${APP}.ads_course_finish_synthesis
select * from ${APP}.ads_course_finish_synthesis
union
select
    '$do_date' dt,
    1  recent_days,
    count(if(video_suc_cnt=video_cnt,user_id,null))  course_finish_user_count,
    count(distinct (if(video_suc_cnt=video_cnt,user_id,null)))  course_finish_count
from (
     select course_id,
            user_id,
            count(distinct video_id) video_suc_cnt
     from ${APP}.dws_study_video_suc_1d
     where dt = '$do_date'
     group by course_id,user_id
    ) t1 left join (
      select course_id,
            count(video_id) video_cnt
      from  ${APP}.dim_chapter_video_full
      where dt = '$do_date'
       group by course_id
    ) t2 on t1.course_id = t2.course_id
union
select
    '$do_date' dt,
     7  recent_days,
    count(if(video_suc_cnt=video_cnt,user_id,null))  course_finish_user_count,
    count(distinct (if(video_suc_cnt=video_cnt,user_id,null)))  course_finish_count
from (
     select course_id,
            user_id,
            count(distinct video_id) video_suc_cnt
     from ${APP}.dws_study_video_suc_1d
     where dt >= date_sub('$do_date',6) and dt<= '$do_date'
     group by course_id,user_id
    ) t1 left join (
      select course_id,
           count(video_id) video_cnt
      from  ${APP}.dim_chapter_video_full
      where dt >= date_sub('$do_date',6) and dt<= '$do_date'
       group by course_id
    ) t2 on t1.course_id = t2.course_id
union
select
    '$do_date' dt,
    30 recent_days,
    count(if(video_suc_cnt=video_cnt,user_id,null))  course_finish_user_count,
    count(distinct (if(video_suc_cnt=video_cnt,user_id,null)))  course_finish_count
from (
     select course_id,
            user_id,
            count(distinct video_id) video_suc_cnt
     from ${APP}.dws_study_video_suc_1d
     where dt >= date_sub('$do_date',6) and dt<= '$do_date'
     group by course_id,user_id
    ) t1 left join (
      select course_id,
           count(video_id) video_cnt
      from  ${APP}.dim_chapter_video_full
      where dt >= date_sub('$do_date',29) and dt<= '$do_date'
       group by course_id
    ) t2 on t1.course_id = t2.course_id;
"
ads_course_finish_avg_user="
insert overwrite table ${APP}.ads_course_finish_avg_user
select * from  ${APP}.ads_course_finish_avg_user
union
select '$do_date' dt,
       1 recent_days,
       course_name,
       count(video_id)/count(distinct user_id)
from ${APP}.dws_study_video_suc_1d t1
left join (
    select id,
           course_name
    from   ${APP}.dim_course_full
    where dt = '$do_date'
    ) dcf on dcf.id = t1.course_id
where dt = '$do_date'
group by course_id,course_name
union
select '$do_date' dt,
       7 recent_days,
       course_name,
       count(video_id)/count(distinct user_id)
from ${APP}.dws_study_video_suc_1d t1
left join (
    select id,
           course_name
    from   ${APP}.dim_course_full
    where dt >= date_sub('$do_date',6)
    ) dcf on dcf.id = t1.course_id
where dt >= date_sub('$do_date',6)
group by course_id,course_name
union
select '$do_date' dt,
       30 recent_days,
       course_name,
       count(video_id)/count(distinct user_id)
from ${APP}.dws_study_video_suc_1d t1
left join (
    select id,
           course_name
    from   ${APP}.dim_course_full
    where dt >= date_sub('$do_date',29)
    ) dcf on dcf.id = t1.course_id
where dt >= date_sub('$do_date',29)
group by course_id,course_name;
"
case $1 in
	"ads_traffic_stats_by_source" )
        hive -e "$ads_traffic_stats_by_source"
    ;;
	"ads_page_path" )
        hive -e "$ads_page_path"
    ;;
	"ads_trade_order_by_source" )
        hive -e "$ads_trade_order_by_source"
    ;;
	"ads_user_change" )
        hive -e "$ads_user_change"
    ;;
	"ads_user_retention" )
        hive -e "$ads_user_retention"
    ;;
	"ads_user_stats" )
        hive -e "$ads_user_stats"
    ;;
	"ads_user_action" )
        hive -e "$ads_user_action"
    ;;
	"ads_new_order_user_stats" )
        hive -e "$ads_new_order_user_stats"
    ;;
	"ads_order_user_age" )
        hive -e "$ads_order_user_age"
    ;;
	"ads_course_order_count" )
        hive -e "$ads_course_order_count"
    ;;
    "ads_subject_order_count" )
        hive -e "$ads_subject_order_count"
    ;;
    "ads_category_order_count" )
        hive -e "$ads_category_order_count"
    ;;
    "ads_course_review_count" )
        hive -e "$ads_course_review_count"
    ;;
    "ads_course_visitor_retention" )
        hive -e "$ads_course_visitor_retention"
    ;;
    "ads_subject_visitor_retention" )
        hive -e "$ads_subject_visitor_retention"
    ;;
    "ads_category_visitor_retention" )
        hive -e "$ads_category_visitor_retention"
    ;;
    "ads_trade_synthesis" )
        hive -e "$ads_trade_synthesis"
    ;;
    "ads_order_by_province" )
        hive -e "$ads_order_by_province"
    ;;
    "ads_paper_synthesis" )
        hive -e "$ads_paper_synthesis"
    ;;
    "ads_course_test" )
        hive -e "$ads_course_test"
    ;;
    "ads_paper_score" )
        hive -e "$ads_paper_score"
    ;;
    "ads_question_currect_rate" )
        hive -e "$ads_question_currect_rate"
    ;;
    "ads_chapter_play" )
        hive -e "$ads_chapter_play"
    ;;
    "ads_course_play" )
        hive -e "$ads_course_play"
    ;;
    "ads_course_finish_synthesis" )
        hive -e "$ads_course_finish_synthesis"
    ;;
    "ads_course_finish_avg_user" )
        hive -e "$ads_course_finish_avg_user"
    ;;
    "ads_course_finish" )
        hive -e "$ads_course_finish"
    ;;
"all" )
        hive -e "$ads_traffic_stats_by_source$ads_page_path$ads_trade_order_by_source$ads_user_change$ads_user_retention$ads_user_stats$ads_user_action$ads_new_order_user_stats$ads_order_user_age$ads_course_order_count$ads_subject_order_count$ads_category_order_count$ads_course_review_count$ads_course_visitor_retention$ads_subject_visitor_retention$ads_category_visitor_retention$ads_trade_synthesis$ads_order_by_province$ads_paper_synthesis$ads_course_test$ads_paper_score$ads_question_currect_rate$ads_chapter_play$ads_course_play$ads_course_finish_synthesis$ads_course_finish_avg_user$ads_course_finish"
    ;;
esac




