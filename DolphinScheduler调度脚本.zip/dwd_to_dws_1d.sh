#!/bin/bash
APP=edu

if [ -n "$2" ] ;then
   do_date=$2
else 
   echo "请传入日期参数"
   exit
fi

dws_traffic_session_page_view_1d="
insert overwrite table ${APP}.dws_traffic_session_page_view_1d partition(dt='$do_date')
select
    session_id,
    mid_id,
    brand,
    model,
    operate_system,
    version_code,
    channel,
    sum(during_time),
    count(*)
from ${APP}.dwd_traffic_page_view_inc
where dt='$do_date'
group by session_id,mid_id,brand,model,operate_system,version_code,channel;
"
dws_trade_user_source_order_1d="
insert overwrite table ${APP}.dws_trade_user_source_order_1d partition(dt='$do_date')
select
    user_id,
    source_id,
    source_site,
    count(distinct(order_id)),
    sum(origin_amount),
    sum(nvl(coupon_reduce,0)),
    sum(final_amount)
from ${APP}.dwd_trade_order_detail_inc
where dt='$do_date'
group by user_id,source_id,source_site;
"
dws_traffic_page_visitor_page_view_1d="
insert overwrite table ${APP}.dws_traffic_page_visitor_page_view_1d partition(dt='$do_date')
select
    mid_id,
    brand,
    model,
    operate_system,
    page_id,
    sum(during_time) during_time_1d,
    count(*)     view_count_1d
from ${APP}.dwd_traffic_page_view_inc
where dt='$do_date'
group by mid_id,brand,model,operate_system,page_id;
"
dws_trade_user_cart_add_1d="
insert overwrite table ${APP}.dws_trade_user_cart_add_1d partition (dt='$do_date')
select
    user_id,
    count(*)
from ${APP}.dwd_trade_cart_add_inc
where dt = '$do_date'
group by user_id;
"
dws_trade_user_payment_1d="
insert overwrite table ${APP}.dws_trade_user_payment_1d partition (dt='$do_date')
select
    user_id,
    count(*) payment_num,
    sum(final_amount) payment_amount
from ${APP}.dwd_trade_pay_detail_suc_inc
where dt = '$do_date'
group by user_id;
"
dws_trade_province_order_1d="
insert overwrite table ${APP}.dws_trade_province_order_1d partition(dt = '$do_date')
select
    province_id,
    province_name,
    area_code    ,
    iso_code     ,
    iso_3166_2  ,
    count(order_id),
    sum(origin_amount),
    sum(coupon_reduce),
    sum(final_amount)
from(
    select
        order_id,
        province_id,
        area_code    ,
        origin_amount,
        coupon_reduce,
        final_amount,
        iso_code     ,
        iso_3166_2,
        name province_name
    from ${APP}.dwd_trade_order_detail_inc
    left join(
    select
        id,
        name,
        area_code    ,
        iso_code     ,
        iso_3166_2
    from ${APP}.dim_province_full
    where dt = '$do_date'
)t2
on province_id = t2.id
    where dt = '$do_date' ) t3
group by province_id,
        province_name,
        area_code    ,
        iso_code     ,
        iso_3166_2;

"
dws_trade_user_course_order_1d="
insert overwrite table ${APP}.dws_trade_user_course_order_1d partition(dt='$do_date')
select
    user_id,
    course_id,
    course_name,
    count(order_id),
    sum(origin_amount),
    sum(nvl(coupon_reduce,0)),
    sum(final_amount)
from ${APP}.dwd_trade_order_detail_inc t1
left join (
    select *
    from ${APP}.dim_course_full
    where dt = '$do_date'
    ) c1
on t1.course_id= c1.id
where t1.dt = '$do_date'
group by user_id,course_id,course_name;
"
dws_interaction_course_order_1d="
insert overwrite table ${APP}.dws_interaction_course_order_1d partition(dt='$do_date')
select
      user_id,
      course_id,
      review_stars
from ${APP}.dwd_interaction_course_review_inc
where  dt ='$do_date';
"
dws_traffic_video_first_1d="
insert overwrite table ${APP}.dws_traffic_video_first_1d partition(dt='$do_date')
select distinct
     user_id
    ,is_new
    ,video_id
    ,chapter_id
    ,course_id
    ,during_sec during_time_1d
    ,cou view_count_1d
from (
      select *
      from ${APP}.dwd_study_user_video_inc
      where dt ='$do_date'
         ) c1
left join (
    select
    user_id u2,
    count(*) cou
    from {APP}.dwd_study_user_video_inc
    where dt = '$do_date'
    group by user_id
    )c2 on c2.u2 = user_id;
"
dws_study_video_suc_1d ="
insert overwrite table ${APP}.dws_study_video_suc_1d partition(dt='$do_date')
select distinct
  t1.user_id,
  t1.course_id,
  t1.chapter_id,
  t1.video_id
from (
 select  distinct  
   user_id,
   course_id,
   chapter_id,
   video_id,
   position_sec
 from ${APP}.dwd_study_user_video_inc
 where dt = '$do_date' and position_sec/during_sec >= 0.9 
) t1
inner join(
select
  user_id,
  course_id,
  chapter_id,
  video_id
from ${APP}.dwd_study_user_video_inc
where dt = '$do_date'
group by user_id,course_id,chapter_id,video_id
having sum(play_sec)>=max(during_sec) 
)t2 on t1.user_id =t2.user_id
and t1.course_id = t2.course_id
and t1.chapter_id = t2.chapter_id
and t1.video_id = t2.video_id;
"
dws_study_user_exam_score_1d="
set hive.cbo.enable=false;
set hive.mapjoin.optimized.hashtable=false;
insert overwrite table ${APP}.dws_study_user_exam_score_1d partition (dt='$do_date')
select
 data.id,
 data.user_id,
 data.paper_id,
 paper_title,
 course_id,
 data.score,
 data.duration_sec
from ${APP}.ods_test_exam_inc  te
left join(
    select *
    from ${APP}.ods_test_paper_full where dt='$do_date'
    )
  tp
on tp.id =  te.data.paper_id
where te.dt = '$do_date' AND type = 'insert';
"
dws_trade_course_order_1d="
insert overwrite table ${APP}.dws_trade_course_order_1d partition(dt='$do_date')
select
    course_id,
    course_name,
    count(order_id),
    count(distinct(user_id)),
    sum(origin_amount),
    sum(nvl(coupon_reduce,0)),
    sum(final_amount)
from ${APP}.dwd_trade_order_detail_inc t1
left join ${APP}.dim_course_full c1
on t1.course_id= c1.id
where c1.dt='$do_date'
group by course_id,course_name;
"
case $1 in
    "dws_traffic_session_page_view_1d" )
        hive -e "$dws_traffic_session_page_view_1d"
    ;;
    "dws_trade_user_source_order_1d" )
        hive -e "$dws_trade_user_source_order_1d"
    ;;
    "dws_traffic_page_visitor_page_view_1d" )
        hive -e "$dws_traffic_page_visitor_page_view_1d"
    ;;
    "dws_trade_user_cart_add_1d" )
        hive -e "$dws_trade_user_cart_add_1d"
    ;;
    "dws_trade_user_payment_1d" )
        hive -e "$dws_trade_user_payment_1d"
    ;;
    "dws_trade_province_order_1d" )
        hive -e "$dws_trade_province_order_1d"
    ;;
    "dws_trade_user_course_order_1d" )
        hive -e "$dws_trade_user_course_order_1d"
    ;;
    "dws_interaction_course_order_1d" )
        hive -e "$dws_interaction_course_order_1d"
    ;;
    "dws_traffic_video_first_1d" )
        hive -e "$dws_traffic_video_first_1d"
    ;;
    "dws_study_video_suc_1d" )
        hive -e "$dws_study_video_suc_1d"
    ;;
    "dws_study_user_exam_score_1d" )
        hive -e "$dws_study_user_exam_score_1d"
    ;;
    "dws_trade_course_order_1d" )
        hive -e "$dws_trade_course_order_1d"
    ;;
    "all" )
        hive -e "$dws_traffic_session_page_view_1d$dws_trade_user_source_order_1d$dws_traffic_page_visitor_page_view_1d$dws_trade_user_cart_add_1d$dws_trade_user_payment_1d$dws_trade_province_order_1d$dws_trade_user_course_order_1d$dws_interaction_course_order_1d$dws_traffic_video_first_1d$dws_study_video_suc_1d$dws_study_user_exam_score_1d$dws_trade_course_order_1d"
    ;;
esac

