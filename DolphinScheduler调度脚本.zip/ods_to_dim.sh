#!/bin/bash

APP=edu

# 如果是输入的日期按照取输入日期；如果没输入日期取当前时间的前一天
if [ -n "$2" ] ;then
    do_date=$2
else 
    do_date=`date -d "-1 day" +%F`
fi

dim_user_zip="
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table ${APP}.dim_user_zip partition(dt)
select
    id,
    login_name,
    nick_name,
    real_name,
    phone_num,
    email,
    user_level,
    birthday,
    gender,
    create_time,
    operate_time,
    start_date,
    if(rn=2,date_sub('$do_date',1),end_date) end_date,
    if(rn=1,'9999-12-31',date_sub('$do_date',1)) dt
from
(
    select
        id,
        login_name,
        nick_name,
        real_name,
        phone_num,
        email,
        user_level,
        birthday,
        gender,
        create_time,
        operate_time,
        start_date,
        end_date,
        row_number() over (partition by id order by start_date desc) rn
    from
    (
        select
            id,
            login_name,
            nick_name,
            real_name,
            phone_num,
            email,
            user_level,
            birthday,
            gender,
            create_time,
            operate_time,
            start_date,
            end_date
        from ${APP}.dim_user_zip
        where dt='9999-12-31'
        union
        select
            id,
            login_name,
            nick_name,
            md5(real_name) real_name,
            md5(if(phone_num regexp '^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\\d{8}$',phone_num,null)) phone_num,
            md5(if(email regexp '^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$',email,null)) email,
            user_level,
            birthday,
            gender,
            create_time,
            operate_time,
            '$do_date' start_date,
            '9999-12-31' end_date
        from
        (
            select
                data.id,
                data.login_name,
                data.nick_name,
                data.real_name,
                data.phone_num,
                data.email,
                data.user_level,
                data.birthday,
                data.gender,
                data.create_time,
                data.operate_time,
                row_number() over (partition by data.id order by ts desc) rn
            from ${APP}.ods_user_info_inc
            where dt='$do_date'
        )t1
        where rn=1
    )t2
)t3;
"
dim_course_full="
insert overwrite table ${APP}.dim_cource_full partition(dt='$do_date')
select
    course_id          -- STRING COMMENT '编id'
  , `course_name`      -- STRING COMMENT '课程名称'
  , `subject_id`       -- STRING COMMENT '学科id'
  , `subject_name`     -- STRING COMMENT '学科名称'
  , `category_id`      -- STRING COMMENT '分类id'
  , `category_name`    -- STRING COMMENT '分类名称'
  , `teacher`          -- STRING COMMENT '讲师名称'
  , `publisher_id`     -- STRING COMMENT '发布者id'
  , `chapter_num`      -- STRING COMMENT '章节数'
  , `origin_price`     -- DECIMAL(16, 2) COMMENT '价格'
  , `reduce_amount`    -- DECIMAL(16, 2) COMMENT '优惠金额'
  , `actual_price`     -- DECIMAL(16, 2) COMMENT '实际价格'
  , `course_introduce` -- STRING COMMENT '课程介绍'
from
(
    select
    `id` as course_id
 , `course_name`
 , `subject_id`
 , `teacher`
 , `publisher_id`
 , `chapter_num`
 , `origin_price`
 , `reduce_amount`
 , `actual_price`
 , `course_introduce`
    from ${APP}.ods_course_info_full as ci
    where dt='$do_date'
)cr
left join
(
    select
        si.id ,
	   subject_name,
	   category_id,
        category_name
    from ${APP}.ods_base_subject_info_full si
	left join (
	select
	id,
	`category_name`
	from ${APP}.ods_base_category_info_full
	    where dt = '$do_date'
	)c2 on c2.id = category_id
    where dt='$do_date'
)sub
on sub.id = cr.subject_id;
"

dim_province_full="
insert overwrite table ${APP}.dim_province_full partition(dt='$do_date')
select
    id,
    name,
    area_code,
    region_id,
    iso_code,
    iso_3166_2
from ${APP}.ods_base_province_full
where dt='$do_date';"

dim_chapter_video_full="
insert overwrite table ${APP}.dim_chapter_video_full partition(dt='$do_date')
select
    `chapter_id`         -- STRING COMMENT '编号id',
   ,`chapter_name`       -- STRING COMMENT '章节名称',
   ,`course_id`          -- STRING COMMENT '课程id',
   ,`course_name`        -- STRING COMMENT '课程名称',
   ,`video_id`           -- STRING COMMENT '视频id',
   ,`publisher_id`       -- STRING COMMENT '发布者id',
   ,`is_free`            -- STRING COMMENT '是否免费',
   ,`video_name`         -- STRING COMMENT '视频名称',
   ,`during_sec`         -- BIGINT COMMENT '视频时长',
   ,`video_status`       -- STRING COMMENT '状态',
   ,`video_size`         -- STRING COMMENT '视频大小',
   ,`video_url`          -- STRING COMMENT '视频存储路径',
   ,`version_id`         -- STRING COMMENT '版本编号',
   ,`video_publisher_id` -- STRING COMMENT '视频发布者id'

from
(
    select
        c1.`id`
      , `chapter_name`
      , `course_id`
      , `course_name`
      , c1.`publisher_id`
      , `is_free`
    from ${APP}.ods_chapter_info_full c1
	left join ${APP}.ods_course_info_full c2
	on c1.course_id = c2.id
    where c1.dt='$do_date' and c2.dt='$do_date'
)cp
left join
(
    select
        `id` as `video_id`
	  , `video_name`
	  , `during_sec`
	  , `video_status`
	  , `video_size`
	  , `video_url`
	  , `video_source_id`
	  , `version_id`
	  , `chapter_id`
	  , `publisher_id`  as  `video_publisher_id`
    from ${APP}.ods_video_info_full
	where dt='$do_date'
)vid
on vid.chapter_id = cp.id;
"


case $1 in
"dim_user_zip")
    hive -e "$dim_user_zip"
;;
"dim_cource_full")
    hive -e "$dim_course_full"
;;
"dim_province_full")
    hive -e "$dim_province_full"
;;
"dim_chapter_video_full")
    hive -e "$dim_chapter_video_full"
;;

"all")
    hive -e "$dim_user_zip$dim_course_full$dim_province_full$dim_chapter_video_full"
;;
esac


