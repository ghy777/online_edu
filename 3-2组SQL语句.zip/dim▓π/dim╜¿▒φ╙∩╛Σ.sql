--1.省份表
DROP TABLE IF EXISTS dim_province_full;
CREATE EXTERNAL TABLE dim_province_full
(
    `id`            STRING COMMENT 'id',
    `name` 			STRING COMMENT '省市名称',
    `area_code`     STRING COMMENT '地区编码',
	`region_id`     STRING COMMENT '大区id',
    `iso_code`      STRING COMMENT '国际编码',
    `iso_3166_2`    STRING COMMENT 'ISO3166 编码'
) COMMENT '地区维度表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dim/dim_province_full/'
    TBLPROPERTIES ('orc.compress' = 'snappy');

--2.日期表
DROP TABLE IF EXISTS dim_date;
CREATE EXTERNAL TABLE dim_date
(
    `date_id`    STRING COMMENT '日期ID',
    `week_id`    STRING COMMENT '周ID,一年中的第几周',
    `week_day`   STRING COMMENT '周几',
    `day`        STRING COMMENT '每月的第几天',
    `month`      STRING COMMENT '一年中的第几月',
    `quarter`    STRING COMMENT '一年中的第几季度',
    `year`       STRING COMMENT '年份',
    `is_workday` STRING COMMENT '是否是工作日',
    `holiday_id` STRING COMMENT '节假日'
) COMMENT '时间维度表'
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dim/dim_date/'
    TBLPROPERTIES ('orc.compress' = 'snappy');

DROP TABLE IF EXISTS tmp_dim_date_info;
CREATE EXTERNAL TABLE tmp_dim_date_info (
    `date_id` STRING COMMENT '日',
    `week_id` STRING COMMENT '周ID',
    `week_day` STRING COMMENT '周几',
    `day` STRING COMMENT '每月的第几天',
    `month` STRING COMMENT '第几月',
    `quarter` STRING COMMENT '第几季度',
    `year` STRING COMMENT '年',
    `is_workday` STRING COMMENT '是否是工作日',
    `holiday_id` STRING COMMENT '节假日'
) COMMENT '时间维度表'
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
LOCATION '/warehouse/online_edu/tmp/tmp_dim_date_info/';


--3.用户表
DROP TABLE IF EXISTS dim_user_zip;
CREATE EXTERNAL TABLE dim_user_zip
(
    `id`           STRING COMMENT '编号',
    `login_name`   STRING COMMENT '用户名称',
    `nick_name`    STRING COMMENT '用户昵称',
    `real_name`    STRING COMMENT '用户姓名',
    `phone_num`    STRING COMMENT '手机号码',
    `email`        STRING COMMENT '邮箱',
    `user_level`   STRING COMMENT '用户等级',
    `birthday`     STRING COMMENT '生日',
    `gender`       STRING COMMENT '性别',
    `create_time`  STRING COMMENT '创建时间',
    `operate_time` STRING COMMENT '操作时间',
    `start_date`   STRING COMMENT '开始时间',
    `end_date`     STRING COMMENT '结束时间'
) COMMENT '用户表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dim/dim_user_zip/'
    TBLPROPERTIES ('orc.compress' = 'snappy');

--4.课程信息表
DROP TABLE IF EXISTS dim_course_full;
CREATE EXTERNAL TABLE dim_course_full
(
    `id`                STRING COMMENT '编号id',
    `course_name`       STRING COMMENT '课程名称',
    `subject_id`        STRING COMMENT '学科id',
    `subject_name`      STRING COMMENT '学科名称',
    `category_id`       STRING COMMENT '分类id',
    `category_name`     STRING COMMENT '分类名称',
    `teacher`           STRING COMMENT '讲师名称',
    `publisher_id`      STRING COMMENT '发布者id',
    `chapter_num`       STRING COMMENT '章节数',
    `origin_price`      DECIMAL(16, 2) COMMENT '价格',
    `reduce_amount`     DECIMAL(16, 2) COMMENT '优惠金额',
    `actual_price`      DECIMAL(16, 2) COMMENT '实际价格',
    `course_introduce`  STRING COMMENT '课程介绍'

) COMMENT '课程维度表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dim/dim_course_full/'
    TBLPROPERTIES ('orc.compress' = 'snappy');


--5.视频章节表
DROP TABLE IF EXISTS dim_chapter_video_full;
CREATE EXTERNAL TABLE dim_chapter_video_full
(
    `id`                   STRING COMMENT '编号id',
    `chapter_name`         STRING COMMENT '章节名称',
    `course_id`            STRING COMMENT '课程id',
    `course_name`          STRING COMMENT '课程名称',
    `video_id`             STRING COMMENT '视频id',
    `publisher_id`         STRING COMMENT '发布者id',
    `is_free`              STRING COMMENT '是否免费',
    `video_name`           STRING COMMENT '视频名称',
    `during_sec`           BIGINT COMMENT '视频时长',
    `video_status`         STRING COMMENT '状态',
    `video_size`           STRING COMMENT  '视频大小',
    `video_url`            STRING COMMENT '视频存储路径',
    `version_id`           STRING COMMENT '版本编号',
    `video_publisher_id`   STRING COMMENT '视频发布者id'
) COMMENT '章节视频维度表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dim/dim_chapter_video_full/'
    TBLPROPERTIES ('orc.compress' = 'snappy');