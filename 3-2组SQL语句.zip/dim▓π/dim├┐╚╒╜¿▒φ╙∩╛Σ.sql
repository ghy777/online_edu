--省份
insert overwrite table dim_province_full partition(dt='2022-02-22')
select
    id,
    name,
    area_code,
    region_id,
    iso_code,
    iso_3166_2
from ods_base_province_full
where dt='2022-02-22';

--用户
--每日装载
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dim_user_zip partition(dt)
select
    id,
    login_name,
    nick_name,
    real_name,
    phone_num,
    email,
    user_level,
    birthday,
    gender,
    create_time,
    operate_time,
    start_date,
    if(rn=2,date_sub('2022-02-22',1),end_date) end_date,
    if(rn=1,'9999-12-31',date_sub('2022-02-22',1)) dt
from
(
    select
        id,
        login_name,
        nick_name,
        real_name,
        phone_num,
        email,
        user_level,
        birthday,
        gender,
        create_time,
        operate_time,
        start_date,
        end_date,
        row_number() over (partition by id order by start_date desc) rn
    from
    (
        select
            id,
            login_name,
            nick_name,
            real_name,
            phone_num,
            email,
            user_level,
            birthday,
            gender,
            create_time,
            operate_time,
            start_date,
            end_date
        from dim_user_zip
        where dt='9999-12-31'
        union
        select
            id,
            login_name,
            nick_name,
            md5(real_name) real_name,
            md5(if(phone_num regexp '^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\\d{8}$',phone_num,null)) phone_num,
            md5(if(email regexp '^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$',email,null)) email,
            user_level,
            birthday,
            gender,
            create_time,
            operate_time,
            '2022-02-22' start_date,
            '9999-12-31' end_date
        from
        (
            select
                data.id,
                data.login_name,
                data.nick_name,
                data.real_name,
                data.phone_num,
                data.email,
                data.user_level,
                data.birthday,
                data.gender,
                data.create_time,
                data.operate_time,
                row_number() over (partition by data.id order by ts desc) rn
            from ods_user_info_inc
            where dt='2022-02-22'
        )t1
        where rn=1
    )t2
)t3;

--课程信息装载
insert overwrite table dim_course_full partition(dt='2022-02-22')
select
    course_id         
  , course_name     
  , subject_id      
  , subject_name    
  , category_id     
  , category_name   
  , teacher          
  , publisher_id     
  , chapter_num    
  , origin_price     
  , reduce_amount    
  , actual_price     
  , course_introduce
from
(
    select
    id as course_id
 , course_name
 , subject_id
 , teacher
 , publisher_id
 , chapter_num
 , origin_price
 , reduce_amount
 , actual_price
 , course_introduce
    from ods_course_info_full as ci
    where dt='2022-02-22'
)cr
left join
(
    select
        si.id ,
	   subject_name,
	   category_id,
        category_name
    from ods_base_subject_info_full si
	left join (
	select
	id,
	category_name
	from ods_base_category_info_full
	    where dt = '2022-02-22'
	)c2 on c2.id = category_id
    where dt='2022-02-22'
)sub
on sub.id = cr.subject_id;


--5.视频章节表
---每日
insert overwrite table dim_chapter_video_full partition(dt='2022-02-22')
select
     id chapter_id         -- STRING COMMENT '编号id',
   ,chapter_name       -- STRING COMMENT '章节名称',
   ,course_id          -- STRING COMMENT '课程id',
   ,course_name        -- STRING COMMENT '课程名称',
   ,video_id           -- STRING COMMENT '视频id',
   ,publisher_id       -- STRING COMMENT '发布者id',
   ,is_free            -- STRING COMMENT '是否免费',
   ,video_name         -- STRING COMMENT '视频名称',
   ,during_sec         -- BIGINT COMMENT '视频时长',
   ,video_status       -- STRING COMMENT '状态',
   ,video_size         -- STRING COMMENT '视频大小',
   ,video_url          -- STRING COMMENT '视频存储路径',
   ,version_id         -- STRING COMMENT '版本编号',
   ,video_publisher_id -- STRING COMMENT '视频发布者id'

from
(
    select
    c1.id
  , chapter_name
  , course_id
  , course_name
  , c1.publisher_id
  , is_free
    from ods_chapter_info_full c1
	left join ods_course_info_full c2
	on c1.course_id = c2.id
    where c1.dt='2022-02-22' and c2.dt='2022-02-22'
)cp
left join
(
    select
        id as video_id
	  , video_name
	  , during_sec
	  , video_status
	  , video_size
	  , video_url
	  , video_source_id
	  , version_id
	  , chapter_id
	  , publisher_id  as  video_publisher_id
    from ods_video_info_full
	where dt='2022-02-22'
)vid
on vid.chapter_id = cp.id;
