

--全量表
--1.分类表
DROP TABLE IF EXISTS ods_base_category_info_full;
CREATE EXTERNAL TABLE ods_base_category_info_full
(
    `id`            STRING COMMENT '编号id',
    `category_name`  STRING COMMENT '分类名称',
    `create_time`   STRING COMMENT '创建时间',
    `update_time`   STRING COMMENT '更新时间',
    `deleted`       STRING COMMENT '是否删除'
) COMMENT '分类表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_base_category_info_full/';

--2.省份表
DROP TABLE IF EXISTS ods_base_province_full;
CREATE EXTERNAL TABLE ods_base_province_full
(
    `id`            STRING COMMENT '编号id',
    `name`          STRING COMMENT '省份名称',
    `region_id`     STRING COMMENT '大区id',
    `area_code`     STRING COMMENT '行政区位码',
    `iso_code`      STRING COMMENT '国际编码',
    `iso_3166_2`    STRING COMMENT 'ISO3166 编码'
) COMMENT '省份表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_base_province_full/';

--3.来源表
DROP TABLE IF EXISTS ods_base_source_full;
CREATE EXTERNAL TABLE ods_base_source_full
(
    `id`            STRING COMMENT '引流来源id',
    `source_site`   STRING COMMENT '引流来源名称',
    `source_url`    STRING COMMENT '引流来源链接'
) COMMENT '来源表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_base_source_full/';

--4.科目表
DROP TABLE IF EXISTS ods_base_subject_info_full;
CREATE EXTERNAL TABLE ods_base_subject_info_full
(
    `id`            STRING COMMENT '编号id',
    `subject_name`  STRING COMMENT '科目名称',
    `category_id`   STRING COMMENT '分类',
    `create_time`   STRING COMMENT '创建时间',
    `update_time`   STRING COMMENT '更新时间',
    `deleted`       STRING COMMENT '是否删除'
) COMMENT '科目表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_base_subject_info_full/';


--5.加购表
DROP TABLE IF EXISTS ods_cart_info_full;
CREATE EXTERNAL TABLE ods_cart_info_full
(
    `id`            STRING COMMENT '编号id',
    `user_id`       STRING COMMENT '用户id',
    `course_id`     STRING COMMENT '课程id',
    `course_name`   STRING COMMENT '课程名称',
    `cart_price`    DECIMAL(16, 2) COMMENT '放入购物车时价格',
    `img_url`       BIGINT COMMENT '图片文件',
    `session_id`    STRING COMMENT '会话id',
    `create_time`    STRING COMMENT '创建时间',
    `update_time`    STRING COMMENT '修改时间',
    `deleted`        STRING COMMENT '是否删除',
    `sold`           STRING COMMENT '是否已售'
) COMMENT '加购表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_cart_info_full/';

--6.章节表
DROP TABLE IF EXISTS ods_chapter_info_full;
CREATE EXTERNAL TABLE ods_chapter_info_full
(
    `id`            STRING COMMENT '编号id',
    `chapter_name`       STRING COMMENT '章节名称',
    `course_id`     STRING COMMENT '课程id',
    `video_id`   STRING COMMENT '视频id',
    `publisher_id`    STRING COMMENT '发布者id',
    `is_free`       STRING COMMENT '是否免费',
    `create_time`    STRING COMMENT '创建时间',
    `update_time`    STRING COMMENT '更新时间',
    `deleted`        STRING COMMENT '是否删除'
) COMMENT '章节表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_chapter_info_full/';



--7.课程信息表
DROP TABLE IF EXISTS ods_course_info_full;
CREATE EXTERNAL TABLE ods_course_info_full
(
    `id`                STRING COMMENT '编号id',
    `course_name`       STRING COMMENT '课程名称',
    `course_slogan`     STRING COMMENT '课程标语',
    `course_cover_url`  STRING COMMENT '课程封面',
    `subject_id`        STRING COMMENT '学科id',
    `teacher`           STRING COMMENT '讲师名称',
    `publisher_id`      STRING COMMENT '发布者id',
    `chapter_num`       STRING COMMENT '章节数',
    `origin_price`      DECIMAL(16, 2) COMMENT '价格',
    `reduce_amount`     DECIMAL(16, 2) COMMENT '优惠金额',
    `actual_price`      DECIMAL(16, 2) COMMENT '实际价格',
    `course_introduce`  STRING COMMENT '课程介绍',
    `create_time`       STRING COMMENT '创建时间',
    `update_time`       STRING COMMENT '更新时间',
    `deleted`           STRING COMMENT '是否删除'
) COMMENT '课程信息表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_course_info_full/';

--8.知识点表
DROP TABLE IF EXISTS ods_knowledge_point_full;
CREATE EXTERNAL TABLE ods_knowledge_point_full
(
    `id`              STRING COMMENT '编号id',
    `point_txt`       STRING COMMENT '知识点内容',
    `point_level`     STRING COMMENT '知识点级别',
    `course_id`       STRING COMMENT '课程id',
    `chapter_id`      STRING COMMENT '章节id',
    `publisher_id`    STRING COMMENT '发布者id',
    `create_time`     STRING COMMENT '创建时间',
    `update_time`     STRING COMMENT '修改时间',
    `deleted`         STRING COMMENT '是否删除'
) COMMENT '知识点表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_knowledge_point_full/';


--9.试卷表
DROP TABLE IF EXISTS ods_test_paper_full;
CREATE EXTERNAL TABLE ods_test_paper_full
(
    `id`              STRING COMMENT '编号id',
    `paper_title`     STRING COMMENT '试卷名称',
    `course_id`       STRING COMMENT '课程id',
    `create_time`     STRING COMMENT '创建时间',
    `update_time`     STRING COMMENT '更新时间',
    `publisher_id`    STRING COMMENT '发布者id',
    `deleted`         STRING COMMENT '是否删除'
) COMMENT '试卷表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_test_paper_full/';


--10.试卷问题表
DROP TABLE IF EXISTS ods_test_paper_question_full;
CREATE EXTERNAL TABLE ods_test_paper_question_full
(
    `id`              STRING COMMENT '编号id',
    `paper_id`        STRING COMMENT '试卷id',
    `question_id`     STRING COMMENT '题目id',
    `score`           DECIMAL(16, 2) COMMENT '得分',
    `create_time`     STRING COMMENT '创建时间',
    `deleted`         STRING COMMENT '是否删除',
    `publisher_id`    STRING COMMENT '发布者id'
) COMMENT '试卷问题表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_test_paper_question_full/';

--11.知识点问题表
DROP TABLE IF EXISTS ods_test_point_question_full;
CREATE EXTERNAL TABLE ods_test_point_question_full
(
    `id`              STRING COMMENT '编号id',
    `point_id`        STRING COMMENT '知识点id ',
    `question_id`     STRING COMMENT '问题id',
    `create_time`     STRING COMMENT '创建时间',
    `publisher_id`    STRING COMMENT '发布者id',
    `deleted`         STRING COMMENT '是否删除'
) COMMENT '知识点问题表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_test_point_question_full/';


--12.用户章节进度表
DROP TABLE IF EXISTS ods_user_chapter_process_full;
CREATE EXTERNAL TABLE ods_user_chapter_process_full
(
    `id`              STRING COMMENT '编号id',
    `course_id`       STRING COMMENT '课程id',
    `chapter_id`      STRING COMMENT '章节id',
    `user_id`         STRING COMMENT '用户id',
    `position_sec`    STRING COMMENT '时长位置',
    `create_time`     STRING COMMENT '创建时间',
    `update_time`     STRING COMMENT '更新时间',
    `deleted`         STRING COMMENT '是否删除'
) COMMENT '用户章节进度表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_user_chapter_process_full/';

--13.视频表
DROP TABLE IF EXISTS ods_video_info_full;
CREATE EXTERNAL TABLE ods_video_info_full
(
 `id`               STRING COMMENT   '编号（主键）',
 `video_name`       STRING COMMENT   '视频名称',
 `during_sec`  	    BIGINT COMMENT   '时长',
 `video_status`     STRING COMMENT   '状态 未上传，上传中，上传完',
 `video_size`       STRING COMMENT   '大小',
 `video_url`        STRING COMMENT   '视频存储路径',
 `video_source_id`  STRING COMMENT   '云端资源编号',
 `version_id`       STRING COMMENT   '版本号',
 `chapter_id`       BIGINT COMMENT   '章节id',
 `course_id`        STRING COMMENT   '课程id',
 `publisher_id`     STRING COMMENT   '发布者id',
 `create_time`      STRING COMMENT   '创建时间',
 `update_time`      STRING COMMENT   '更新时间',
 `deleted`          STRING COMMENT   '是否删除'
) COMMENT '视频表'
 PARTITIONED BY (`dt` STRING)
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    NULL DEFINED AS ''
    LOCATION '/warehouse/online_edu/ods/ods_video_info_full';
--增量表
--1.加购表（增量）
DROP TABLE IF EXISTS ods_cart_info_inc;
CREATE EXTERNAL TABLE ods_cart_info_inc
(
    `type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<id :STRING,user_id :STRING,course_id :STRING,course_name :STRING,cart_price :DECIMAL(16, 2),img_url :STRING,session_id :STRING,
                  create_time :STRING,update_time :STRING,deleted :STRING,sold :STRING >,
    `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '购物车增量表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_cart_info_inc/';

--2.章节评价表
DROP TABLE IF EXISTS ods_comment_info_inc;
CREATE EXTERNAL TABLE ods_comment_info_inc
(
    `type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<id :STRING,user_id :STRING,chapter_id :STRING,course_id :STRING,comment_txt :STRING,create_time :STRING,deleted
                  :STRING> COMMENT '数据',
    `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '章节评价表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_comment_info_inc/';

--3.收藏表
DROP TABLE IF EXISTS ods_favor_info_inc;
CREATE EXTERNAL TABLE ods_favor_info_inc
(
    `type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<id :STRING,course_id :STRING,user_id :STRING,create_time :STRING,update_time :STRING,deleted :STRING> COMMENT '数据',
    `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '收藏表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_favor_info_inc/';

--4.订单明细表
DROP TABLE IF EXISTS ods_order_detail_inc;
CREATE EXTERNAL TABLE ods_order_detail_inc
(
    `type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<id :STRING,user_id :STRING,course_id :STRING,course_name :STRING,order_id :STRING,origin_amount :DECIMAL(16,2),coupon_reduce :DECIMAL(16,2),
    final_amount :DECIMAL(16,2),create_time :STRING,update_time :STRING
    > COMMENT '数据',
    `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '订单明细表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_order_detail_inc/';

--5.订单表
DROP TABLE IF EXISTS ods_order_info_inc;
CREATE EXTERNAL TABLE ods_order_info_inc
(
    `type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<id :STRING,user_id :STRING,origin_amount :DECIMAL(16,2),coupon_reduce :DECIMAL(16,2),final_amount :DECIMAL(16,2),
order_status :STRING,out_trade_no :STRING,trade_body :STRING,session_id :STRING,province_id :STRING,create_time :STRING,expire_time :STRING,
update_time :STRING> COMMENT '数据',
    `old`  MAP<STRING,STRING> COMMENT '旧值'
)   COMMENT '订单表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_order_info_inc/';

--6.支付表
DROP TABLE IF EXISTS ods_payment_info_inc;
CREATE EXTERNAL TABLE ods_payment_info_inc
(
    `type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<id :STRING,out_trade_no :STRING,order_id :STRING,alipay_trade_no :STRING,total_amout :DECIMAL(16,2),
    trade_body :STRING,payment_type :STRING,payment_status :STRING,create_time :STRING,update_time :STRING,callback_content :STRING,
callback_time :STRING
    > COMMENT '数据',
    `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '支付表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_payment_info_inc/';

--7.课程评价表
DROP TABLE IF EXISTS ods_review_info_inc;
CREATE EXTERNAL TABLE ods_review_info_inc
(
    `type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<id :STRING,user_id :STRING,course_id :STRING,review_txt :STRING,review_stars :BIGINT,
    create_time :STRING,deleted :STRING> COMMENT '数据',
    `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '课程评价表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_review_info_inc/';

--8.日志表
DROP TABLE IF EXISTS ods_log_inc;
CREATE EXTERNAL TABLE ods_log_inc
(
    `common`   STRUCT<ar :STRING,ba :STRING,ch :STRING,is_new :STRING,md :STRING,mid :STRING,os :STRING,sc:STRING,sid:STRING,uid :STRING,vc
                      :STRING> COMMENT '公共信息',
    `page`     STRUCT<during_time :STRING,item :STRING,item_type :STRING,last_page_id :STRING,page_id
                      :STRING,source_type :STRING> COMMENT '页面信息',
    `actions`  ARRAY<STRUCT<action_id:STRING,item:STRING,item_type:STRING,ts:BIGINT>> COMMENT '动作信息',
    `displays` ARRAY<STRUCT<display_type :STRING,item :STRING,item_type :STRING,`order` :STRING,pos_id
                            :STRING>> COMMENT '曝光信息',
    `start`    STRUCT<entry :STRING,loading_time :BIGINT,open_ad_id :BIGINT,open_ad_ms :BIGINT,open_ad_skip_ms
                      :BIGINT> COMMENT '启动信息',
    `err`      STRUCT<error_code:BIGINT,msg:STRING> COMMENT '错误信息',
	`ts`       BIGINT  COMMENT '时间戳',
	`appVideo` STRUCT<play_sec:BIGINT,position_sec:BIGINT,video_id:STRING>
) COMMENT '日志表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_log_inc';

--9.VIP变化表(vip_change_detail_inc)
DROP TABLE IF EXISTS ods_vip_change_detail_inc;
CREATE EXTERNAL TABLE ods_vip_change_detail_inc
(
   `type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<
        id:STRING,
        user_id:STRING,
        from_vip:BIGINT ,
        to_vip:BIGINT,
        create_time:STRING
        > COMMENT '数据',
    `old`  MAP<STRING,STRING> COMMENT '旧值'

) COMMENT 'VIP变化表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_vip_change_detail_inc';


--10.用户表
DROP TABLE IF EXISTS ods_user_info_inc;
CREATE EXTERNAL TABLE ods_user_info_inc
(
    `type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<id :STRING,login_name :STRING,nick_name :STRING,passwd :STRING,real_name :STRING,phone_num :STRING,email
                  :STRING,head_img :STRING,user_level :STRING,birthday :STRING,gender :STRING,create_time :STRING,operate_time
                  :STRING,status :STRING> COMMENT '数据',
    `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '用户表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_user_info_inc';


--11.测验表(test_exam_inc)
DROP TABLE IF EXISTS ods_test_exam_inc;
CREATE EXTERNAL TABLE ods_test_exam_inc
(
	`type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<
        id:STRING,
        paper_id  :STRING,
        user_id :STRING,
        score:STRING,
        duration_sec:BIGINT,
        create_time:STRING,
        submit_time:STRING,
        update_time:STRING,
        deleted:STRING
        > COMMENT '数据',
    `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '测验表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_test_exam_inc';


--12.测验问题表（test_exam_question_inc）
DROP TABLE IF EXISTS ods_test_exam_question_inc;
CREATE EXTERNAL TABLE ods_test_exam_question_inc
(
`type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<
        id         :STRING,
        exam_id    :STRING,
        paper_id   :STRING,
        question_id:STRING,
        user_id    :STRING,
        answer     :STRING,
        is_correct :STRING,
        score      :BIGINT,
        create_time:STRING,
        update_time:STRING,
        deleted    :STRING
        > COMMENT '数据',
    `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '测验表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_test_exam_question_inc';


--13.问题信息表
DROP TABLE IF EXISTS ods_test_question_info_inc;
CREATE EXTERNAL TABLE ods_test_question_info_inc
(
	`type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<
         id:STRING,
         question_txt:STRING,
         chapter_id:STRING,
         course_id:STRING,
         question_type:STRING,
         create_time:STRING,
         update_time:STRING,
         publisher_id:STRING,
         deleted :STRING
        > COMMENT '数据',
      `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '测验表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_test_question_info_inc';


--14.问题选项表
DROP TABLE IF EXISTS ods_test_question_option_inc;
CREATE EXTERNAL TABLE ods_test_question_option_inc
(
	`type` STRING COMMENT '变动类型',
    `ts`   BIGINT COMMENT '变动时间',
    `data` STRUCT<
         id:STRING,
         option_txt:STRING,
         question_id:STRING,
         is_correct:STRING,
         create_time:STRING,
         update_time:STRING,
         deleted:STRING
        > COMMENT '数据',
      `old`  MAP<STRING,STRING> COMMENT '旧值'
) COMMENT '测验表'
    PARTITIONED BY (`dt` STRING)
    ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.JsonSerDe'
    LOCATION '/warehouse/online_edu/ods/ods_test_question_option_inc';





