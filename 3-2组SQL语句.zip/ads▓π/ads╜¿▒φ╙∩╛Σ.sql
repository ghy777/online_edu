--1.1.1 各来源流量统计
DROP TABLE IF EXISTS ads_traffic_stats_by_source;
CREATE EXTERNAL TABLE ads_traffic_stats_by_source
(
    `dt`               STRING COMMENT '统计日期',
    `recent_days`      BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `source_site`      STRING COMMENT '来源',
    `uv_count`         BIGINT COMMENT '访客人数',
    `avg_duration_sec` BIGINT COMMENT '会话平均停留时长，单位为秒',
    `avg_page_count`   BIGINT COMMENT '会话平均浏览页面数',
    `sv_count`         BIGINT COMMENT '会话数',
    `bounce_rate`      DECIMAL(16, 2) COMMENT '跳出率'
) COMMENT '各渠道流量统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_traffic_stats_by_source/';

--1.1.2. 路径分析
DROP TABLE IF EXISTS ads_page_path;
CREATE EXTERNAL TABLE ads_page_path
(
    `dt`          STRING COMMENT '统计日期',
    `source`      STRING COMMENT '跳转起始页面ID',
    `target`      STRING COMMENT '跳转终到页面ID',
    `path_count`  BIGINT COMMENT '跳转次数'
) COMMENT '页面浏览路径分析'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_page_path/';

--1.1.3 各来源下单统计
DROP TABLE IF EXISTS ads_trade_order_by_source;
CREATE EXTERNAL TABLE ads_trade_order_by_source
(
    `dt`                      STRING COMMENT '统计日期',
    `recent_days`             BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `source`                  STRING COMMENT '来源',
    `uv_count`                BIGINT COMMENT '访客人数',
    `order_user_count`        BIGINT COMMENT '下单用户统计',
    `order_amount_count`      BIGINT COMMENT '下单金额统计',
    `order_rate`              DECIMAL(16, 2) COMMENT '转化率'
) COMMENT '各来源流量统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_traffic_stats_by_source/';


--1.2.1用户变动统计
DROP TABLE IF EXISTS ads_user_change;
CREATE EXTERNAL TABLE ads_user_change
(
    `dt`               STRING COMMENT '统计日期',
    `user_churn_count` BIGINT COMMENT '流失用户数',
    `user_back_count`  BIGINT COMMENT '回流用户数'
) COMMENT '用户变动统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_user_change/';


--1.2.2用户留存率

DROP TABLE IF EXISTS ads_user_retention;
CREATE EXTERNAL TABLE ads_user_retention
(
    `dt`              STRING COMMENT '统计日期',
    `create_date`     STRING COMMENT '用户新增日期',
    `retention_day`   INT COMMENT '截至当前日期留存天数',
    `retention_count` BIGINT COMMENT '留存用户数量',
    `new_user_count`  BIGINT COMMENT '新增用户数量',
    `retention_rate`  DECIMAL(16, 2) COMMENT '留存率'
) COMMENT '用户留存率'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_user_retention/';

--1.2.3用户新增活跃统计
DROP TABLE IF EXISTS ads_user_stats;
CREATE EXTERNAL TABLE ads_user_stats
(
    `dt`                STRING COMMENT '统计日期',
    `recent_days`       BIGINT COMMENT '最近n日,1:最近1日,7:最近7日,30:最近30日',
    `new_user_count`    BIGINT COMMENT '新增用户数',
    `active_user_count` BIGINT COMMENT '活跃用户数'
) COMMENT '用户新增活跃统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_user_stats/';

--1.2.4用户行为漏斗分析

DROP TABLE IF EXISTS ads_user_action;
CREATE EXTERNAL TABLE ads_user_action
(
    `dt`                BIGINT COMMENT '统计日期',
    `recent_days`       STRING COMMENT '最近n日,1:最近1日,7:最近7日,30:最近30日',
    `home_count`        BIGINT COMMENT '浏览首页人数',
    `course_detail_count` BIGINT COMMENT '浏览课程详情页人数',
    `cart_count`        BIGINT COMMENT '加入购物车人数',
    `order_count`       BIGINT COMMENT '下单人数',
    `payment_count`     BIGINT COMMENT '支付人数'
) COMMENT '漏斗分析'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_user_action/';

--1.2.5新增交易用户统计
DROP TABLE IF EXISTS ads_new_order_user_stats;
CREATE EXTERNAL TABLE ads_new_order_user_stats
(
    `dt`                   STRING COMMENT '统计日期',
    `recent_days`          BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `new_order_user_count` BIGINT COMMENT '新增下单人数'
) COMMENT '新增交易用户统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_new_order_user_stats/';


--1.2.6各年龄段下单用户数
DROP TABLE IF EXISTS ads_order_user_age;
CREATE EXTERNAL TABLE ads_order_user_age
(
    `dt`                   STRING COMMENT '统计日期',
    `recent_days`          BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `order_user_count_minor`     BIGINT COMMENT '未成年下单人数',
    `order_user_count_youth`     BIGINT COMMENT '青年下单人数',
    `order_user_count_midlife`     BIGINT COMMENT '中年下单人数',
    `order_user_count_aged`     BIGINT COMMENT '老年下单人数'
) COMMENT '交易用户年龄段统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_order_user_age/';

--1.3.1-课程下单统计

DROP TABLE IF EXISTS ads_course_order_count;
CREATE EXTERNAL TABLE ads_course_order_count
(
    `dt`                   STRING COMMENT '统计日期',
    `recent_days`          BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `course_name`          STRING COMMENT '课程名称',
    `order_count`          BIGINT COMMENT '订单统计',
    `order_user_count`     BIGINT COMMENT '下单用户统计',
    `order_amount_count`   BIGINT COMMENT '下单金额统计'
) COMMENT '各课程交易统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_course_order_count/';

--1.3.2-学科下单统计

DROP TABLE IF EXISTS ads_subject_order_count;
CREATE EXTERNAL TABLE ads_subject_order_count
(
    `dt`                   STRING COMMENT '统计日期',
    `recent_days`          BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `order_count`          BIGINT COMMENT '订单统计',
    `order_user_count`     BIGINT COMMENT '下单用户统计',
    `order_amount_count`   BIGINT COMMENT '下单金额统计'
) COMMENT '学科下单统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_subject_order_count/';

--1.3.3 分类下单统计

DROP TABLE IF EXISTS ads_category_order_count;
CREATE EXTERNAL TABLE ads_category_order_count
(
    `dt`                   STRING COMMENT '统计日期',
    `recent_days`          BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `category_name`        STRING COMMENT '分类名称',
    `order_count`          BIGINT COMMENT '订单统计',
    `order_user_count`     BIGINT COMMENT '下单用户统计',
    `order_amount_count`   BIGINT COMMENT '下单金额统计'
) COMMENT '分类下单统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_category_order_count/';

--1.3.4课程评价统计

DROP TABLE IF EXISTS ads_course_review_count;
CREATE EXTERNAL TABLE ads_course_review_count
(
    `dt`                   STRING COMMENT '统计日期',
    `recent_days`          BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `course_name`          STRING COMMENT '课程名称',
    `user_review_avg`      BIGINT COMMENT '用户平均评分',
    `review_user_count`    BIGINT COMMENT '评价用户统计',
    `hige_review_rate`     DECIMAL(16, 2) COMMENT '好评率'
) COMMENT '课程评价统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_course_review_count/';

--1.3.5课程试听留存统计1-7
DROP TABLE IF EXISTS ads_course_visitor_retention;
CREATE EXTERNAL TABLE ads_course_visitor_retention
(
    `dt`                   STRING COMMENT '统计日期',
    `recent_days`          BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `course_name`          STRING COMMENT '课程名称',
    `course_visitor`       BIGINT COMMENT '试听人数',
    `course_visitor_retention_rate`    DECIMAL(16, 2) COMMENT '试听留存率'

) COMMENT '课程试听留存统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_course_visitor_retention/';

--1.3.6学科试听留存1-7
DROP TABLE IF EXISTS ads_subject_visitor_retention;
CREATE EXTERNAL TABLE ads_subject_visitor_retention
(
    `dt`                   STRING COMMENT '统计日期',
    `recent_days`           BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `subject_name`          STRING COMMENT '学科名称',
    `subject_visitor`       BIGINT COMMENT '试听人数',
    `subject_visitor_retention_rate`    DECIMAL(16,2) COMMENT '试听留存率'

) COMMENT '学科试听留存'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_subject_visitor_retention/';

--1.3.7分类试听留存1-7
DROP TABLE IF EXISTS ads_category_visitor_retention;
CREATE EXTERNAL TABLE ads_category_visitor_retention
(
    `dt`                   STRING COMMENT '统计日期',
    `retention_day`          BIGINT COMMENT '1-7天',
    `category_name`          STRING COMMENT '分类名称',
    `category_visitor`       BIGINT COMMENT '试听人数',
    `category_visitor_retention_rate`    DECIMAL(16,2) COMMENT '试听留存率'

) COMMENT '分类试听留存'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_category_visitor_retention/';

--1.4.1 交易综合统计
DROP TABLE IF EXISTS ads_trade_synthesis;
CREATE EXTERNAL TABLE ads_trade_synthesis
(
    `dt`                   STRING COMMENT '统计日期',
    `recent_days`          BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `order_amount`         BIGINT COMMENT '下单金额',
    `order_num`            BIGINT COMMENT '下单数',
    `order_user_num`       BIGINT COMMENT '下单人数'

) COMMENT '交易综合统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_trade_synthesis/';

--1.4.2 各省份交易统计

DROP TABLE IF EXISTS ads_order_by_province;
CREATE EXTERNAL TABLE ads_order_by_province
(
    `dt`                 STRING COMMENT '统计日期',
    `recent_days`        BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `province_id`        STRING COMMENT '省份ID',
    `province_name`      STRING COMMENT '省份名称',
    `area_code`          STRING COMMENT '地区编码',
    `iso_code`           STRING COMMENT '国际标准地区编码',
    `iso_code_3166_2`    STRING COMMENT '国际标准地区编码',
    `order_count`        BIGINT COMMENT '订单数',
    `order_total_amount` DECIMAL(16, 2) COMMENT '订单金额'
) COMMENT '各省份交易统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_order_by_province/';

--1.5.1各试卷相关指标统计
DROP TABLE IF EXISTS ads_paper_synthesis;
CREATE EXTERNAL TABLE ads_paper_synthesis
(
    `dt`                     STRING COMMENT '统计日期',
    `recent_days`            BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `paper_title`            STRING COMMENT '试卷标题',
    `paper_score_avg`        DECIMAL(16,2) COMMENT '平均分',
    `paper_duration_avg`     BIGINT COMMENT '平均时长',
    `paper_user_count`       BIGINT COMMENT '用户数'

) COMMENT '各试卷相关指标统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_paper_synthesis/';
--1.5.2各课程考试相关指标统计
DROP TABLE IF EXISTS ads_course_test;
CREATE EXTERNAL TABLE ads_course_test
(
    `dt`                     STRING COMMENT '统计日期',
    `recent_days`            BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `course_name`            STRING COMMENT '课程名称',
    `course_score_avg`        BIGINT COMMENT '平均分',
    `course_duration_avg`     BIGINT COMMENT '平均时长',
    `course_user_count`       BIGINT COMMENT '用户数'
--1.5.3各试卷分数分布统计
DROP TABLE IF EXISTS ads_paper_score;
CREATE EXTERNAL TABLE ads_paper_score
(
    `dt`                      STRING COMMENT '统计日期',
    `recent_days`             BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `paper_title`             STRING COMMENT '试卷标题',
    `score_under_60`          BIGINT COMMENT '小于60人数',
    `score_under_60_70`          BIGINT COMMENT '60_70人数',
    `score_under_70_80`          BIGINT COMMENT '70_80人数',
    `score_under_80_90`          BIGINT COMMENT '80_90人数',
    `score_under_90_100`         BIGINT COMMENT '90_1000人数'

) COMMENT '各试卷分数分布统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_paper_score/';

--1.5.4各题目正确率统计
DROP TABLE IF EXISTS ads_question_currect_rate;
CREATE EXTERNAL TABLE ads_question_currect_rate
(
    `dt`                           STRING COMMENT '统计日期',
    `recent_days`                  BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `question_txt`                 STRING COMMENT '问题名称',
    `question_correct_rate`        DECIMAL(16,2) COMMENT '正确率'

) COMMENT '各题目正确率统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_question_correct_rate/';
--1.6.1各章节视频播放情况统计
 DROP TABLE IF EXISTS ads_chapter_play;
CREATE EXTERNAL TABLE ads_chapter_play
(
    `dt`                           STRING COMMENT '统计日期',
    `recent_days`                  BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `chapter_name`                 STRING COMMENT '章节名称',
    `chapter_play_coun`            BIGINT COMMENT '章节播放次数',
    `chapter_user_paly_avg`        BIGINT COMMENT '人均播放时长',
    `chapter_user_count`           BIGINT COMMENT '观看人数'

) COMMENT '各章节视频播放情况统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_chapter_play/';


--1.6.2各课程视频播放情况统计
DROP TABLE IF EXISTS ads_chapter_play;
CREATE EXTERNAL TABLE ads_chapter_play
(
    `dt`                           STRING COMMENT '统计日期',
    `recent_days`                  BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `chapter_name`                 STRING COMMENT '章节名称',
    `chapter_play_coun`            BIGINT COMMENT '章节播放次数',
    `chapter_user_paly_avg`        BIGINT COMMENT '人均播放时长',
    `chapter_user_count`           BIGINT COMMENT '观看人数'
--1.7.1各课程完课人数统计
DROP TABLE IF EXISTS ads_course_play;
CREATE EXTERNAL TABLE ads_course_play
(
    `dt`                           STRING COMMENT '统计日期',
    `recent_days`                  BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `course_name`                 STRING COMMENT '课程名称',
    `course_play_count`            BIGINT COMMENT '课程播放次数',
    `course_user_paly_avg`        BIGINT COMMENT '人均播放时长',
    `course_user_count`           BIGINT COMMENT '观看人数'

) COMMENT '各课程视频播放情况统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_course_play/';
--1.7.2 完课综合指标
DROP TABLE IF EXISTS ads_course_finish;
CREATE EXTERNAL TABLE ads_course_finish
(
    `dt`                           STRING COMMENT '统计日期',
    `recent_days`                  BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `course_name`                 STRING COMMENT '课程名称',
    `course_user_finish_count`      BIGINT COMMENT '完课人数'

) COMMENT '各课程完课人数统计'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_course_finish/';

--1.7.3 各课程人均完成章节视频数统计

DROP TABLE IF EXISTS ads_course_finish_synthesis;
CREATE EXTERNAL TABLE ads_course_finish_synthesis
(
    `dt`                           STRING COMMENT '统计日期',
    `recent_days`                  BIGINT COMMENT '最近天数,1:最近1天,7:最近7天,30:最近30天',
    `course_finish_user_count`     BIGINT COMMENT '总完课人数',
    `course_finish_count`          BIGINT COMMENT '总完课人次'
) COMMENT '完课综合指标'
    ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
    LOCATION '/warehouse/online_edu/ads/ads_course_finish_synthesis/';
