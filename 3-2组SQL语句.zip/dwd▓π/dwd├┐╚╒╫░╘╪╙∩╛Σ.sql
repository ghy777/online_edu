--1.交易域加购物车事务事实表
--每日装载
insert overwrite table dwd_trade_order_detail_inc partition (dt='2022-02-22')
select
    odfo.id,
    order_id,
    odfo.user_id,
    course_id,
    province_id,
    date_format(create_time, 'yyyy-MM-dd') date_id,
    create_time,
    origin_amount,
    coupon_reduce,
    final_amount,
    session_id,
    source_id,
    source_site
from (
         select data.id,
                data.user_id,
                data.order_id,
                data.course_id,
                data.create_time,
                data.origin_amount,
                data.coupon_reduce,
                data.final_amount,
                province_id,
                session_id
         from ods_order_detail_inc ord
         left join
            (
                select
                    data.id,
                    data.province_id,
                    data.session_id
                from ods_order_info_inc
                where dt = '2022-02-22'
                and type = 'insert'
            ) oi on oi.id = ord.data.order_id
          where dt = '2022-02-22' and type = 'insert'
     ) odfo
left join (
			select
				common.uid,
				common.sc source_id,
				common.sid,
				source_site,
				actions[0]
			from ods_log_inc l1
			left join ods_base_source_full s1
			on l1.common.sc=s1.id
			where l1.dt='2022-02-22' and actions.action_id is not null and  actions.action_id[0] = 'cart_add'
)log on odfo.session_id = log.sid;


--2.交易域下单明细事务事实表
--每日装载
insert overwrite table dwd_trade_order_detail_inc partition (dt='2022-02-22')
select
    odfo.id,
    order_id,
    odfo.user_id,
    course_id,
    province_id,
    date_format(create_time, 'yyyy-MM-dd') date_id,
    create_time,
    origin_amount,
    coupon_reduce,
    final_amount,
    session_id,
    source_id,
    source_site
from (
         select data.id,
                data.user_id,
                data.order_id,
                data.course_id,
                data.create_time,
                data.origin_amount,
                data.coupon_reduce,
                data.final_amount,
                province_id,
                session_id
         from ods_order_detail_inc ord
         left join
            (
                select
                    data.id,
                    data.province_id,
                    data.session_id
                from ods_order_info_inc
                where dt = '2022-02-22'
                and type = 'insert'
            ) oi on oi.id = ord.data.order_id
          where dt = '2022-02-22' and type = 'insert'
     ) odfo
left join (
			select
				common.uid,
				common.sc source_id,
				common.sid,
				source_site,
				actions[0]
			from ods_log_inc l1
			left join ods_base_source_full s1
			on l1.common.sc=s1.id
			where l1.dt='2022-02-22' and actions.action_id is not null and  actions.action_id[0] = 'cart_add'
)log on odfo.session_id = log.sid;

--3.交易域支付成功事务事实表
--每日装载
insert overwrite table dwd_trade_pay_detail_suc_inc partition (dt='2022-02-22')
select
    id      ,
    order_id,
    user_id ,
    province_id ,
    payment_type,
    payment_status,
    date_format(callback_time,'yyyy-MM-dd') date_id,
    callback_time,
    origin_amount,
    coupon_reduce,
    final_amount
from
(
    select
        data.order_id  opid,
        data.payment_type,
        data.payment_status,
        data.callback_time
    from ods_payment_info_inc
    where dt='2022-02-22'
    and type='insert'
    --and array_contains(map_keys(old),'payment_status')
    and data.payment_status='1602'
) pi
join
(
    select
        data.id,
        data.order_id,
        data.user_id,
        data.origin_amount,
        data.coupon_reduce,
        data.final_amount
    from ods_order_detail_inc
    where (dt = '2022-02-22' or dt = date_add('2022-02-22',1))
    and (type = 'insert' or type = 'bootstrap-insert')
) od
on od.order_id=opid
left join
(
    select
        data.id  oi_id,
        data.province_id
    from ods_order_info_inc
    where (dt = '2022-02-22' or dt = date_sub('2022-02-22',1))
    and (type = 'insert' or type = 'bootstrap-insert')
) oi
on od.order_id = oi_id;

--4.流量域页面浏览事务事实表
--每日装载
set hive.cbo.enable=false;
insert overwrite table dwd_traffic_page_view_inc partition (dt='2022-02-22')
select distinct
    province_id,
    brand,
    channel,
    source_id,
    source_site,
    is_new,
    model,
    mid_id,
    operate_system,
    user_id,
    version_code,
    page_item,
    page_item_type,
    last_page_id,
    page_id,
    date_format(from_utc_timestamp(ts,'GMT+8'),'yyyy-MM-dd') date_id,
    date_format(from_utc_timestamp(ts,'GMT+8'),'yyyy-MM-dd HH:mm:ss') view_time,
    concat(mid_id,'-',last_value(session_start_point,true) over (partition by mid_id order by ts)) session_id,
    during_time
from
(
    select
        common.ar province_id,
        common.ba brand,
        common.ch channel,
        common.sc source_id,
        common.is_new is_new,
        common.md model,
        common.mid mid_id,
        common.os operate_system,
        common.uid user_id,
        common.vc version_code,
        page.during_time,
        page.item page_item,
        page.item_type page_item_type,
        page.last_page_id,
        page.page_id,
        ts,
        if(page.last_page_id is null,ts,null) session_start_point
    from ods_log_inc
    where dt='2022-02-22'
    and page.page_id is not null
) t1
left join (
    select id,
           source_site
    from ods_base_source_full
    where dt = '2022-02-22'
    ) t2 on t1.source_id = t2.id;

--5.用户域用户登录事务事实表
insert overwrite table dwd_user_login_inc partition(dt='2022-02-22')
select
    user_id,
    date_format(from_utc_timestamp(ts,'GMT+8'),'yyyy-MM-dd') date_id,
    date_format(from_utc_timestamp(ts,'GMT+8'),'yyyy-MM-dd HH:mm:ss') login_time,
    channel,
    province_id,
    version_code,
    mid_id,
    brand,
    model,
    operate_system
from
(
    select
        user_id,
        channel,
        area_code,
        version_code,
        mid_id,
        brand,
        model,
        operate_system,
        ts
    from
    (
        select
            user_id,
            channel,
            area_code,
            version_code,
            mid_id,
            brand,
            model,
            operate_system,
            ts,
            row_number() over (partition by session_id order by ts) rn
        from
        (
            select
                user_id,
                channel,
                area_code,
                version_code,
                mid_id,
                brand,
                model,
                operate_system,
                ts,
                concat(mid_id,'-',last_value(session_start_point,true) over(partition by mid_id order by ts)) session_id
            from
            (
                select
                    common.uid user_id,
                    common.ch channel,
                    common.ar area_code,
                    common.vc version_code,
                    common.mid mid_id,
                    common.ba brand,
                    common.md model,
                    common.os operate_system,
                    ts,
                    if(page.last_page_id is null,ts,null) session_start_point
                from ods_log_inc
                where dt='2022-02-22'
                and page.page_id is not null
            )t1
        )t2
        where user_id is not null
    )t3
    where rn=1
)t4
left join
(
    select
        id province_id,
        area_code
    from ods_base_province_full
    where dt='2022-02-22'
)bp
on t4.area_code=bp.province_id;


--6.交易域购物车周期快照事实表
--数据装载
insert overwrite table dwd_trade_cart_full partition(dt='2022-02-21')
select
    data.id,
    data.user_id,
    data.course_id,
    data.course_name
from ods_cart_info_inc
where dt='2022-02-21'
and data.sold='0';
--7.互动域收藏事实表

--m每日
insert overwrite table dwd_interaction_favor_add_inc partition(dt='2022-02-22')
SELECT
        fav_id,
        user_id,
        course_id,
        course_name,
        subject_id,
        subject_name,
        category_id,
        category_name,
        teacher,
        chapter_num,
		date_id,
        create_time
FROM
(
SELECT
          data.id fav_id,
          data.user_id,
		  data.course_id,
		  data.create_time,
		  date_format(data.create_time,'yyyy-MM-dd') date_id
FROM  ods_favor_info_inc
WHERE 	dt ='2022-02-22'
AND type ='insert'
) fi
LEFT JOIN
    (
        select *
        from dim_course_full
        where dt = '2022-02-22'
        )
     dcf
ON fi.course_id = dcf.id;

--8.互动域课程评价表
insert overwrite table dwd_interaction_course_review_inc partition(dt ='2022-02-22')
	SELECT
      data.id,
      data.user_id,
      data.course_id,
      data.review_stars,
	  date_format(data.create_time,'yyyy-MM-dd'	) date_id,
      data.create_time
	FROM  ods_review_info_inc
	WHERE 	dt ='2022-02-22'
	AND type = 'insert';
--9.互动域章节评论表
-每日
insert overwrite table dwd_interaction_chapter_comment_inc partition(dt='2022-02-22')
SELECT
	    id,
	 	user_id     ,
		chapter_id  ,
		chapter_name,
		video_id    ,
		video_name  ,
		course_id   ,
		comment_txt ,
		date_id,
		create_time
FROM
(
SELECT
       data.user_id,
       data.chapter_id,
       data.course_id,
       data.comment_txt ,
       data.create_time ,
	   date_format(data.create_time,'yyyy-MM-dd') date_id
FROM ods_comment_info_inc
WHERE  dt = '2022-02-22'
AND type = 'insert'
)comi
LEFT JOIN
(
SELECT
		id chaid,
	    chapter_name,
		video_id
FROM ods_chapter_info_full
WHERE dt = '2022-02-22'
)chapi
ON comi.chapter_id = chaid
LEFT JOIN
(
SELECT
    id,
	video_name
FROM  ods_video_info_full
WHERE dt = '2022-02-22'
)vid
on chapi.video_id = vid.id
--10.学习域用户章节视频播放表
insert overwrite TABLE dwd_study_user_video_inc partition(dt='2022-02-22')
select
       user_id,
       course_id,
       chapter_id,
       video_id,
       during_sec,
       play_sec,
       position_sec,
       is_new,
       dt date_id
from (
    select
        common.uid as user_id,
        appVideo.video_id,
        appvideo.play_sec,
        appvideo.position_sec,
        common.is_new,
        dt
    from ods_log_inc
    where appvideo.video_id is not null AND dt = '2022-02-22'
) log
left join
    (select id,
            course_id,
            chapter_id,
            during_sec
     from ods_video_info_full
     where dt = '2022-02-22'
    )vi
on log.video_id = vi.id;
