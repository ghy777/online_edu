--1.流量域会话粒度页面浏览最近1日汇总表
DROP TABLE IF EXISTS dws_traffic_session_page_view_1d;
CREATE EXTERNAL TABLE dws_traffic_session_page_view_1d
(
    `session_id`     STRING COMMENT '会话id',
    `mid_id`         string comment '设备id',
    `brand`          string comment '手机品牌',
    `model`          string comment '手机型号',
    `operate_system` string comment '操作系统',
    `version_code`   string comment 'app版本号',
    `channel`        string comment '渠道',
    `during_time_1d` BIGINT COMMENT '最近1日访问时长',
    `page_count_1d`  BIGINT COMMENT '最近1日访问页面数'
) COMMENT '流量域会话粒度页面浏览最近1日汇总表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_traffic_session_page_view_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');


--2.交易域用户粒度订单最近1日汇总事实表

DROP TABLE IF EXISTS dws_trade_user_source_order_1d;
CREATE EXTERNAL TABLE dws_trade_user_source_order_1d
(
    `user_id`                   STRING COMMENT '用户id',
    `source_id`                 STRING COMMENT '来源id',
    `source_site`              STRING COMMENT '来源名称',
    `order_count_1d`            BIGINT COMMENT '最近1日下单次数',
    `order_original_amount_1d`  DECIMAL(16, 2) COMMENT '最近1日下单原始金额',
    `coupon_reduce_amount_1d`   DECIMAL(16, 2) COMMENT '优惠券减免',
    `order_total_amount_1d`     DECIMAL(16, 2) COMMENT '最近1日下单最终金额'
) COMMENT '交易域用户粒度订单最近1日汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_trade_user_source_order_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');

--3.用户域用户粒度登录历史至今汇总事实表
DROP TABLE IF EXISTS dws_user_user_login_td;
CREATE EXTERNAL TABLE dws_user_user_login_td
(
    `user_id`         STRING COMMENT '用户id',
    `login_date_last` STRING COMMENT '末次登录日期',
    `login_count_td`  BIGINT COMMENT '累计登录次数'
) COMMENT '用户域用户粒度登录历史至今汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_user_user_login_td'
    TBLPROPERTIES ('orc.compress' = 'snappy');

--4.流量域访客页面粒度页面浏览最近1日汇总事实表
DROP TABLE IF EXISTS dws_traffic_page_visitor_page_view_1d;
CREATE EXTERNAL TABLE dws_traffic_page_visitor_page_view_1d
(
    `mid_id`         STRING COMMENT '访客id',
    `brand`          string comment '手机品牌',
    `model`          string comment '手机型号',
    `operate_system` string comment '操作系统',
    `page_id`        STRING COMMENT '页面id',
    `during_time_1d` BIGINT COMMENT '最近1日浏览时长',
    `view_count_1d`  BIGINT COMMENT '最近1日访问次数'
) COMMENT '流量域访客页面粒度页面浏览最近1日汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_traffic_page_visitor_page_view_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');

--5.交易域用户粒度加购最近1日汇总事实表
DROP TABLE IF EXISTS dws_trade_user_cart_add_1d;
CREATE EXTERNAL TABLE dws_trade_user_cart_add_1d
(
    `user_id`           STRING COMMENT '用户id',
    `cart_add_count_1d` BIGINT COMMENT '最近1日加购次数'
) COMMENT '交易域用户粒度加购最近1日汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_trade_user_cart_add_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');


--6.交易域用户粒度支付最近1日汇总事实表

DROP TABLE IF EXISTS dws_trade_user_payment_1d;
CREATE EXTERNAL TABLE dws_trade_user_payment_1d
(
    `user_id`           STRING COMMENT '用户id',
    `payment_count_1d`  BIGINT COMMENT '最近1日支付次数',
    `payment_amount_1d` DECIMAL(16, 2) COMMENT '最近1日支付金额'
) COMMENT '交易域用户粒度支付最近1日汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_trade_user_payment_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');


--7.交易域省份粒度订单最近1日汇总事实表
DROP TABLE IF EXISTS dws_trade_province_order_1d;
CREATE EXTERNAL TABLE dws_trade_province_order_1d
(
    `province_id`               STRING COMMENT '省份id',
    `province_name`             STRING COMMENT '省份名称',
    `area_code`                 STRING COMMENT '地区编码',
    `iso_code`                  STRING COMMENT '旧版ISO-3166-2编码',
    `iso_3166_2`                STRING COMMENT '新版版ISO-3166-2编码',
    `order_count_1d`            BIGINT COMMENT '最近1日下单次数',
    `order_original_amount_1d`  DECIMAL(16, 2) COMMENT '最近1日下单原始金额',
    `coupon_reduce_amount_1d`   DECIMAL(16, 2) COMMENT '最近1日下单优惠券优惠金额',
    `order_total_amount_1d`     DECIMAL(16, 2) COMMENT '最近1日下单最终金额'
) COMMENT '交易域省份粒度订单最近1日汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_trade_province_order_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');


--8.交易域省份粒度订单最近n日汇总事实表

DROP TABLE IF EXISTS dws_trade_province_order_nd;
CREATE EXTERNAL TABLE dws_trade_province_order_nd
(
    `province_id`                STRING COMMENT '省份id',
    `province_name`              STRING COMMENT '省份名称',
    `area_code`                  STRING COMMENT '地区编码',
    `iso_code`                   STRING COMMENT '旧版ISO-3166-2编码',
    `iso_3166_2`                 STRING COMMENT '新版版ISO-3166-2编码',
    `order_count_7d`             BIGINT COMMENT '最近7日下单次数',
    `order_original_amount_7d`   DECIMAL(16, 2) COMMENT '最近7日下单原始金额',
    `activity_reduce_amount_7d`  DECIMAL(16, 2) COMMENT '最近7日下单活动优惠金额',
    `order_total_amount_7d`      DECIMAL(16, 2) COMMENT '最近7日下单最终金额',
    `order_count_30d`            BIGINT COMMENT '最近30日下单次数',
    `order_original_amount_30d`  DECIMAL(16, 2) COMMENT '最近30日下单原始金额',
    `coupon_reduce_amount_30d`   DECIMAL(16, 2) COMMENT '最近30日下单优惠券优惠金额',
    `order_total_amount_30d`     DECIMAL(16, 2) COMMENT '最近30日下单最终金额'
) COMMENT '交易域省份粒度订单最近n日汇总事实表'
    PARTITIONED BY (`dt` STRING)
 STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_trade_province_order_nd'
    TBLPROPERTIES ('orc.compress' = 'snappy');

--9.交易域课程粒度订单最近1日汇总事实表

DROP TABLE IF EXISTS dws_trade_user_course_order_1d;
CREATE EXTERNAL TABLE dws_trade_user_course_order_1d
(
    user_id                     STRING COMMENT '用户id',
    `course_id`                 STRING COMMENT '课程id',
    `course_name`               STRING COMMENT '课程名称',
    `order_count_1d`            BIGINT COMMENT '最近1日下单次数',
    --`order_u_count_1d`          BIGINT COMMENT '最近1日下单人数',
    `order_original_amount_1d`  DECIMAL(16, 2) COMMENT '最近1日下单原始金额',
    `coupon_reduce_amount_1d`   DECIMAL(16, 2) COMMENT '最近1日下单优惠券优惠金额',
    `order_total_amount_1d`     DECIMAL(16, 2) COMMENT '最近1日下单最终金额'
) COMMENT '交易域课程粒度订单最近1日汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_trade_user_course_order_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');

--10 交易域用户粒度订单历史至今汇总事实表

DROP TABLE IF EXISTS dws_trade_user_order_td;
CREATE EXTERNAL TABLE dws_trade_user_order_td
(
    `user_id`                   STRING COMMENT '用户id',
    `order_date_first`          STRING COMMENT '首次下单日期',
    `order_date_last`           STRING COMMENT '末次下单日期',
    `order_count_td`            BIGINT COMMENT '下单次数',
    `original_amount_td`        DECIMAL(16, 2) COMMENT '原始金额',
    `coupon_reduce_amount_td`   DECIMAL(16, 2) COMMENT '优惠金额',
    `total_amount_td`           DECIMAL(16, 2) COMMENT '最终金额'
) COMMENT '交易域用户粒度订单历史至今汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_trade_user_order_td'
    TBLPROPERTIES ('orc.compress' = 'snappy');


--11.互动域课程粒度评论最近1日汇总事实表

DROP TABLE IF EXISTS dws_interaction_course_order_1d;
CREATE EXTERNAL TABLE dws_interaction_course_order_1d
(
    `user_id`                   STRING COMMENT '用户id',
    `course_id`                 STRING COMMENT '课程id',
    `review_stars`              BIGINT COMMENT '评论等级'

) COMMENT '互动域课程粒度评论最近1日汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_interaction_course_order_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');
select * from dws_interaction_course_order_1d where dt = '2022-02-22';


--12.流量域访客页面粒度页面浏览最近1日汇总事实表
DROP TABLE IF EXISTS dws_traffic_video_first_1d;
CREATE EXTERNAL TABLE dws_traffic_video_first_1d
(
    `user_id`        STRING COMMENT '用户id',
    `is_new`         STRING COMMENT '是否为新用户',
    `video_id`       string comment '视频id',
    `chapter_id`     string comment '章节id',
    `course_id`      string comment '课程id',
    `during_time_1d` BIGINT COMMENT '最近1日浏览时长',
    `view_count_1d`  BIGINT COMMENT '最近1日访问次数'
) COMMENT '流量域访客页面粒度页面浏览最近1日汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_traffic_video_first_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');


--13.学习域用户观看视频完课表
DROP TABLE IF EXISTS dws_study_video_suc_1d;
CREATE EXTERNAL TABLE   dws_study_video_suc_1d    --这个是视频播放完成的表 播放时长大于等于90%就出现在这里
(

    `user_id`             		STRING COMMENT '用户id', -- 用户课程粒度
	`course_id`               	STRING COMMENT '课程',
	`chapter_id`               	STRING COMMENT '章节',
	`video_id`               	STRING COMMENT '视频' -- 一个章节对应多个视频
) COMMENT '学习域用户观看视频完课表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_study_video_suc_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');   


--14学习域测验粒度用户考试得分最近1日汇总事实表
DROP TABLE IF EXISTS dws_study_user_exam_score_1d;
CREATE EXTERNAL TABLE dws_study_user_exam_score_1d
(
 `id`                  STRING COMMENT '测验id', --这里加测验id主要是为了表名粒度
 `user_id`               STRING COMMENT '用户id',
    `paper_id`                STRING COMMENT '试卷id',
    `paper_title`               STRING COMMENT '试卷名称',
 course_id     STRING COMMENT '课程id',
    `score`                  bigint COMMENT '分数',
    `duration_sec`              bigint COMMENT '所用时长'
) COMMENT '考试域测验粒度用户考试得分最近1日汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_study_user_exam_score_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');

-- 15交易域课程粒度订单汇总表

DROP TABLE IF EXISTS dws_trade_course_order_1d;
CREATE EXTERNAL TABLE dws_trade_course_order_1d
(
    `course_id`                 STRING COMMENT '课程id',
    `course_name`               STRING COMMENT '课程名称',
    `order_count_1d`            BIGINT COMMENT '最近1日下单次数',
    `order_u_count_1d`          BIGINT COMMENT '最近1日下单人数',
    `order_original_amount_1d`  DECIMAL(16, 2) COMMENT '最近1日下单原始金额',
    `coupon_reduce_amount_1d`   DECIMAL(16, 2) COMMENT '最近1日下单优惠券优惠金额',
    `order_total_amount_1d`     DECIMAL(16, 2) COMMENT '最近1日下单最终金额'
) COMMENT '交易域课程粒度订单最近1日汇总事实表'
    PARTITIONED BY (`dt` STRING)
    STORED AS ORC
    LOCATION '/warehouse/online_edu/dws/dws_trade_course_order_1d'
    TBLPROPERTIES ('orc.compress' = 'snappy');
