--1.流量域会话粒度页面浏览最近1日汇总表
insert overwrite table dws_traffic_session_page_view_1d partition(dt='2022-02-22')
select
    session_id,
    mid_id,
    brand,
    model,
    operate_system,
    version_code,
    channel,
    sum(during_time),
    count(*)
from dwd_traffic_page_view_inc
where dt='2022-02-22'
group by session_id,mid_id,brand,model,operate_system,version_code,channel;

--2.交易域用户粒度订单最近1日汇总事实表
insert overwrite table dws_trade_user_source_order_1d partition(dt='2022-02-22')
select
    user_id,
    source_id,
    source_site,
    count(distinct(order_id)),
    sum(origin_amount),
    sum(nvl(coupon_reduce,0)),
    sum(final_amount)
from dwd_trade_order_detail_inc
where dt='2022-02-22'
group by user_id,source_id,source_site;

--3.用户域用户粒度登录历史至今汇总事实表
insert overwrite table dws_user_user_login_td partition(dt='2022-02-22')
select
    nvl(old.user_id,new.user_id),
    if(new.user_id is null,old.login_date_last,'2022-02-22'),
    nvl(old.login_count_td,0)+nvl(new.login_count_1d,0)
from
(
    select
        user_id,
        login_date_last,
        login_count_td
    from dws_user_user_login_td
    where dt=date_sub('2022-02-22',1)
)old
full outer join
(
    select
        user_id,
        count(*) login_count_1d
    from dwd_user_login_inc
    where dt='2022-02-22'
    group by user_id
)new
on old.user_id=new.user_id;
--4.流量域访客页面粒度页面浏览最近1日汇总事实表
insert overwrite table dws_traffic_page_visitor_page_view_1d partition(dt='2022-02-22')
select
    mid_id,
    brand,
    model,
    operate_system,
    page_id,
    sum(during_time) during_time_1d,
    count(*)     view_count_1d
from dwd_traffic_page_view_inc
where dt='2022-02-22'
group by mid_id,brand,model,operate_system,page_id;

--5.交易域用户粒度加购最近1日汇总事实表
insert overwrite table dws_trade_user_cart_add_1d partition (dt='2022-02-21')
select
    user_id,
    count(*)
from dwd_trade_cart_add_inc
where dt = '2022-02-21'
group by user_id;
--首日
insert overwrite table dws_trade_user_cart_add_1d partition (dt='2022-02-22')
select
    user_id,
    count(*)
from dwd_trade_cart_add_inc
where dt = '2022-02-22'
group by user_id;

--6.交易域用户粒度支付最近1日汇总事实表
insert overwrite table dws_trade_user_payment_1d partition (dt='2022-02-22')
select
    user_id,
    count(*) payment_num,
    sum(final_amount) payment_amount
from dwd_trade_pay_detail_suc_inc
where dt = '2022-02-22'
group by user_id;

--7.交易域省份粒度订单最近1日汇总事实表
insert overwrite table dws_trade_province_order_1d partition(dt = '2022-02-22')
select
    province_id,
    province_name,
    area_code    ,
    iso_code     ,
    iso_3166_2  ,
    count(order_id),
    sum(origin_amount),
    sum(coupon_reduce),
    sum(final_amount)
from(
    select
        order_id,
        province_id,
        area_code    ,
        origin_amount,
        coupon_reduce,
        final_amount,
        iso_code     ,
        iso_3166_2,
        name province_name
    from dwd_trade_order_detail_inc
    left join(
    select
        id,
        name,
        area_code    ,
        iso_code     ,
        iso_3166_2
    from dim_province_full
    where dt = '2022-02-22'
)t2
on province_id = t2.id
    where dt = '2022-02-22' ) t3
group by province_id,
        province_name,
        area_code    ,
        iso_code     ,
        iso_3166_2;
--8.交易域省份粒度订单最近n日汇总事实表
insert overwrite table dws_trade_province_order_nd partition(dt='2022-02-22')
select
    province_id,
    province_name,
    area_code,
    iso_code,
    iso_3166_2,
    sum(if(dt>=date_add('2022-02-22',-6),order_count_1d,0)),
    sum(if(dt>=date_add('2022-02-22',-6),order_original_amount_1d,0)),
    sum(if(dt>=date_add('2022-02-22',-6),coupon_reduce_amount_1d,0)),
    sum(if(dt>=date_add('2022-02-22',-6),order_total_amount_1d,0)),
    sum(order_count_1d),
    sum(order_original_amount_1d),
    sum(coupon_reduce_amount_1d),
    sum(order_total_amount_1d)
from dws_trade_province_order_1d
where dt>=date_add('2022-02-22',-29)
and dt<='2022-02-22'
group by province_id,province_name,area_code,iso_code,iso_3166_2;


--9.交易域课程粒度订单最近1日汇总事实表
insert overwrite table dws_trade_user_course_order_1d partition(dt='2022-02-22')
select
    user_id,
    course_id,
    course_name,
    count(order_id),
    sum(origin_amount),
    sum(nvl(coupon_reduce,0)),
    sum(final_amount)
from dwd_trade_order_detail_inc t1
left join (
    select *
    from dim_course_full
    where dt = '2022-02-22'
    ) c1
on t1.course_id= c1.id
where t1.dt = '2022-02-22'
group by user_id,course_id,course_name;

--10 交易域用户粒度订单历史至今汇总事实表
insert overwrite table dws_trade_user_order_td partition(dt='2022-02-22')
select
    nvl(old.user_id,new.user_id),
    if(new.user_id is not null and old.user_id is null,'2022-02-22',old.order_date_first),
    if(new.user_id is not null,'2022-02-22',old.order_date_last),
    nvl(old.order_count_td,0)+nvl(new.order_count_1d,0),
    nvl(old.original_amount_td,0)+nvl(new.order_original_amount_1d,0),
    nvl(old.coupon_reduce_amount_td,0)+nvl(new.coupon_reduce_amount_1d,0),
    nvl(old.total_amount_td,0)+nvl(new.order_total_amount_1d,0)
from
(
    select
        user_id,
        order_date_first,
        order_date_last,
        order_count_td,
        original_amount_td,
        coupon_reduce_amount_td,
        total_amount_td
    from dws_trade_user_order_td
    where dt=date_add('2022-02-22',-1)
)old
full outer join
(
    select
        user_id,
        order_count_1d,
        order_original_amount_1d,
        coupon_reduce_amount_1d,
        order_total_amount_1d
    from dws_trade_user_course_order_1d
    where dt='2022-02-22'
)new
on old.user_id=new.user_id;

--11.互动域课程粒度评论最近1日汇总事实表
insert overwrite table dws_interaction_course_order_1d partition(dt='2022-02-22')
select
      user_id,
      course_id,
      review_stars
from dwd_interaction_course_review_inc
where  dt ='2022-02-22';

--12.流量域访客页面粒度页面浏览最近1日汇总事实表
insert overwrite table dws_traffic_page_visitor_page_view_1d partition(dt='2022-02-22')
select
    mid_id,
    brand,
    model,
    operate_system,
    page_id,
    sum(during_time),
    count(*)
from dwd_traffic_page_view_inc
where dt='2022-02-22'
group by mid_id,brand,model,operate_system,page_id;

--13.学习域用户观看视频完课表
--每日
insert overwrite table dws_study_video_suc_1d partition(dt='2022-02-22')
select distinct
  t1.user_id,
  t1.course_id,
  t1.chapter_id,
  t1.video_id
from (
 select  distinct  --这里写distinct是考虑到可能有观看百分之90，又观看百分之95的情况
   user_id,
   course_id,
   chapter_id,
   video_id,
   position_sec
 from dwd_study_user_video_inc
 where dt = '2022-02-22' and position_sec/during_sec >= 0.9 --position_sec 是播放进度  during_sec是视频时长
) t1
inner join(
select
  user_id,
  course_id,
  chapter_id,
  video_id
from dwd_study_user_video_inc
where dt = '2022-02-22'
group by user_id,course_id,chapter_id,video_id
having sum(play_sec)>=max(during_sec) --这里表示我的累积观看总时长大于等于总时长的90%
)t2 on t1.user_id =t2.user_id
and t1.course_id = t2.course_id
and t1.chapter_id = t2.chapter_id
and t1.video_id = t2.video_id;

--14学习域测验粒度用户考试得分最近1日汇总事实表
--每日
set hive.cbo.enable=false;
set hive.mapjoin.optimized.hashtable=false;
insert overwrite table dws_study_user_exam_score_1d partition (dt='2022-02-22')
select
 data.id,
 data.user_id,
 data.paper_id,
 paper_title,
 course_id,
 data.score,
 data.duration_sec
from ods_test_exam_inc  te
left join(
    select *
    from ods_test_paper_full where dt='2022-02-22'
    )
  tp
on tp.id =  te.data.paper_id
where te.dt = '2022-02-22' AND type = 'insert';

-- 15交易域课程粒度订单汇总表
insert overwrite table dws_trade_course_order_1d partition(dt='2022-02-22')
select
    course_id,
    course_name,
    count(order_id),
    count(distinct(user_id)),
    sum(origin_amount),
    sum(nvl(coupon_reduce,0)),
    sum(final_amount)

from dwd_trade_order_detail_inc t1
left join dim_course_full c1
on t1.course_id= c1.id
where c1.dt='2022-02-22'
group by course_id,course_name;